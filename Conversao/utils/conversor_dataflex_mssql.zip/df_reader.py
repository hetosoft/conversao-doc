# /// script
# requires-python = ">=3.10"
# ///
"""Leitor do banco embedded do DataFlex (formato ISAM proprietario) — stdlib pura, zero licenca.

Formato (reverse-engineered no export MercadoTina; ver PROJETO.md):
  - Registros de tamanho fixo, depois de um header de metadados. Ha DOIS layouts de dados:
      * CONTIGUO: registro N em header + N*reclen.
      * PAGINADO: registros agrupados em paginas (512B na MercadoTina) e um registro NAO
        cruza a fronteira da pagina; sobra padding no fim de cada uma. Registro i da pagina
        p em header + p*pagina + i*reclen, com pagina // reclen registros por pagina.
    Provado na SECAO (reclen 85): o registro 6 comeca em 3584 (= 3072 + 512), nao em 3582
    (= 3072 + 6*85). Lida como paginada, devolve 23 secoes com CODIGO 1..23 sequencial e
    nomes coerentes; lida como contigua, as 5 primeiras saem certas e as 18 seguintes saem
    lixo.
  - QUAL layout cada tabela usa NAO e assumido: quem decide e df_layout, provando por
    invariantes dos proprios bytes (header por consenso da base, pagina por tabela). A
    versao anterior deste leitor decidia pelo resto de (filesize - 3072) % reclen, e o modo
    de falha era o pior possivel — ler contiguo uma tabela paginada nao levanta erro,
    produz dado plausivel e errado a partir da segunda pagina, e a verificacao por contagem
    nao pega porque origem e destino saem da mesma leitura. Ver df_layout.
  - reclen: uint16 LE em 0x9A.
  - Tabela de descritores em 0x2E0, 8 bytes por campo (1-based):
      b0-b1 = offset do campo no registro (LE16, 1-based)
      b3    = tamanho fisico do campo em bytes
      b4    = tipo: 0=ASCII, 1=NUM (BCD), 2=DATE
      b2    = (indice<<4) | flags; DECIMAIS do NUM = (b2 & 0x0F) * 2
  - ASCII: bytes -> texto (dados MercadoTina sao ASCII sem acento; cp850 seguro).
  - NUM: BCD de todos os nibbles com o TOP nibble do byte0 mascarado (flag/sinal); valor / 10^dec.
  - DATE: BCD idem -> contador de dias desde 1900-01-01; 0 => None (vazio).

Nomes/ordem dos campos vem do .FD (#REPLACE tabela.CAMPO |F<T><file>,<idx>); o tipo do .FD
e conferido contra o b4 do header (header vence).
"""
import datetime
import decimal
import os
import re

import df_layout

HEADER = 0x0C00          # 3072 — inicio dos dados (fixo)
RECLEN_OFF = 0x9A        # uint16 LE
DESC_OFF = 0x2E0         # tabela de descritores
DESC_SZ = 8
PAGINA = 0x200           # 512 — pagina de dados; registro nao cruza a fronteira
DATE_EPOCH = datetime.date(1900, 1, 1)   # dia 0; offset exato a confirmar (+-1..2d)
CODEPAGE = "cp850"       # DOS-origin; dados MercadoTina sao ASCII puro (code page moot)

TIPO_ASC, TIPO_NUM, TIPO_DATE = 0, 1, 2


def _find(folder, base, exts):
    for e in exts:
        for c in (base, base.lower(), base.upper(), base.capitalize()):
            p = os.path.join(folder, c + e)
            if os.path.exists(p):
                return p
    return None


def _parse_fd(dd_dir, name):
    """Nomes e ordem dos campos a partir do .FD. -> {idx: nome}."""
    p = _find(dd_dir, name, [".FD", ".fd"])
    if not p:
        return {}
    out = {}
    for line in open(p, encoding="latin-1"):
        m = re.match(r"#REPLACE\s+\w+\.(\w+)\s*\|F[NSD]\d+,(\d+)", line)
        if m:
            out[int(m.group(2))] = m.group(1)
    return out


# Letra de tipo do .FD -> tipo do header. S=string, N=numerico, D=data.
_FD_TIPO = {"S": TIPO_ASC, "N": TIPO_NUM, "D": TIPO_DATE}


def _parse_fd_tipos(dd_dir, name):
    """Tipo declarado no .FD por campo. -> {idx: tipo} (so os que sabemos mapear).

    Serve de conferencia cruzada contra o b4 do header: sao duas fontes independentes
    dizendo o tipo do mesmo campo, e divergencia entre elas e sinal de que o descritor nao
    esta sendo lido onde pensamos. O header continua vencendo na decodificacao — o .FD e
    texto gerado e pode estar dessincronizado do .dat — mas a divergencia e reportada.
    """
    p = _find(dd_dir, name, [".FD", ".fd"])
    if not p:
        return {}
    out = {}
    for line in open(p, encoding="latin-1"):
        m = re.match(r"#REPLACE\s+\w+\.(\w+)\s*\|F([NSD])\d+,(\d+)", line)
        if m and m.group(2) in _FD_TIPO:
            out[int(m.group(3))] = _FD_TIPO[m.group(2)]
    return out


def _bcd_masked(raw: bytes) -> int:
    """BCD de todos os nibbles, mascarando o top nibble do byte0 (flag/sinal DataFlex)."""
    if not raw:
        return 0
    nibs = [raw[0] & 0x0F]
    for b in raw[1:]:
        nibs.append(b >> 4)
        nibs.append(b & 0x0F)
    s = "".join(str(n) for n in nibs if n <= 9)
    return int(s) if s else 0


def _decode(raw: bytes, tipo: int, dec: int):
    if tipo == TIPO_ASC:
        return raw.decode(CODEPAGE, "replace").rstrip("\x00 ") or None
    if tipo == TIPO_NUM:
        v = _bcd_masked(raw)
        if dec:
            return decimal.Decimal(v).scaleb(-dec)
        return v
    if tipo == TIPO_DATE:
        days = _bcd_masked(raw)
        if days == 0:
            return None
        try:
            return DATE_EPOCH + datetime.timedelta(days=days)
        except OverflowError:
            return None
    return raw.decode(CODEPAGE, "replace").rstrip("\x00 ") or None


# --------------------------------------------------------------- layout descoberto
# Prefixo lido de cada .dat para descobrir o layout. Cobre com folga a amostra de 400
# registros e as 512 paginas do teste de padding, sem carregar os 100 MB do PRODUTOS.
PREFIXO_DESCOBERTA = 2 * 1024 * 1024

_cache_header: dict[str, dict] = {}
_cache_pagina: dict[tuple[str, str], dict] = {}


def _prefixo(base_dir: str, name: str) -> tuple[bytes, int, list]:
    """(prefixo do .dat, reclen, campos) — o suficiente para pontuar layouts."""
    datp = _find(os.path.join(base_dir, "Data"), name, [".dat", ".DAT"])
    if not datp:
        raise FileNotFoundError(f"{name}.dat nao encontrado em {base_dir}\\Data")
    filesize = os.path.getsize(datp)
    with open(datp, "rb") as f:
        buf = f.read(min(filesize, PREFIXO_DESCOBERTA))
    fd_names = _parse_fd(os.path.join(base_dir, "DDSrc"), name)
    reclen, campos = table_meta(buf, fd_names, filesize, name)
    return buf, reclen, campos


def _nomes_de_tabela(base_dir: str) -> list[str]:
    data = os.path.join(base_dir, "Data")
    vistos, nomes = set(), []
    for f in sorted(os.listdir(data)):
        if not f.lower().endswith(".dat"):
            continue
        n = os.path.splitext(f)[0]
        if n.lower() not in vistos:
            vistos.add(n.lower())
            nomes.append(n)
    return nomes


def layout_da_base(base_dir: str, amostra: int = 12) -> dict:
    """Header do formato, descoberto por consenso entre as maiores tabelas da base.

    O header e constante do FORMATO, nao da tabela — por isso sai de um consenso, e nao de
    cada arquivo isolado (ver a docstring de df_layout). Resultado em cache por base_dir.
    """
    if base_dir in _cache_header:
        return _cache_header[base_dir]

    candidatas = []
    for n in _nomes_de_tabela(base_dir):
        try:
            buf, reclen, campos = _prefixo(base_dir, n)
        except (FormatoNaoSuportado, FileNotFoundError):
            continue           # arquivo que o leitor nao cobre nao vota no header
        candidatas.append((os.path.getsize(
            _find(os.path.join(base_dir, "Data"), n, [".dat", ".DAT"])), n, buf, reclen, campos))
    candidatas.sort(reverse=True, key=lambda x: x[0])
    amostras = [(n, buf, reclen, campos) for _sz, n, buf, reclen, campos in candidatas[:amostra]]

    resultado = df_layout.descobrir_header(amostras)
    _cache_header[base_dir] = resultado
    return resultado


def layout_da_tabela(base_dir: str, name: str) -> dict:
    """Tamanho de pagina desta tabela, provado pelos invariantes. Cache por (base, tabela).

    Levanta df_layout.TabelaVazia quando nao ha registro, e df_layout.LayoutIndeterminado
    quando o arquivo nao e legivel como DataFlex.
    """
    chave = (base_dir, name.lower())
    if chave in _cache_pagina:
        return _cache_pagina[chave]
    header = layout_da_base(base_dir)["header"]
    buf, reclen, campos = _prefixo(base_dir, name)
    r = df_layout.escolher_pagina(buf, reclen, campos, header, name)
    r["reclen"] = reclen
    _cache_pagina[chave] = r
    return r


def paginado(filesize: int, reclen: int) -> bool:
    """True quando os registros sao agrupados em paginas de PAGINA bytes (ver docstring do modulo).

    Discriminante: no layout contiguo a regiao de dados e multiplo exato de reclen; quando nao e,
    o excedente e o padding no fim de cada pagina.
    """
    return (filesize - HEADER) % reclen != 0


def registros_por_pagina(reclen: int) -> int:
    """Quantos registros inteiros cabem numa pagina. 0 quando o registro nao cabe."""
    return PAGINA // reclen


def offsets(filesize: int, reclen: int, tabela: str = ""):
    """Offset de cada slot de registro, no layout que este arquivo usa (contiguo ou paginado)."""
    if not paginado(filesize, reclen):
        for r in range((filesize - HEADER) // reclen):
            yield HEADER + r * reclen
        return

    por_pagina = registros_por_pagina(reclen)
    if por_pagina < 1:
        raise FormatoNaoSuportado(
            f"{tabela}: layout paginado com reclen {reclen} maior que a pagina ({PAGINA}) — "
            f"nao sabemos onde cada registro comeca. Nao suportado.")
    pagina = 0
    while True:
        base = HEADER + pagina * PAGINA
        if base >= filesize:
            return
        for i in range(por_pagina):
            o = base + i * reclen
            if o + reclen > filesize:
                return
            yield o
        pagina += 1


class FormatoNaoSuportado(Exception):
    """A estrutura do .dat sai do que este leitor cobre (versao/compressao/Unicode/tipo de campo).
    Preferimos falhar RUIDOSO aqui a produzir dado silenciosamente errado — o formato foi
    reverse-engineered de um unico export (MercadoTina) e nao vale pra qualquer DataFlex."""


def table_meta(dat: bytes, fd_names: dict, filesize: int, tabela: str = ""):
    """(reclen, [ (idx, nome, off, length, tipo, dec) ]) do header, com guardas fail-loud.
    Levanta FormatoNaoSuportado quando as premissas do formato nao batem."""
    reclen = int.from_bytes(dat[RECLEN_OFF:RECLEN_OFF + 2], "little")
    if not 0 < reclen <= 65535:
        raise FormatoNaoSuportado(
            f"{tabela}: reclen invalido ({reclen}) em 0x9A — versao/layout de DataFlex nao suportado.")
    if filesize <= HEADER:
        raise FormatoNaoSuportado(
            f"{tabela}: arquivo ({filesize}B) <= header ({HEADER}B) — vazio ou formato nao reconhecido.")
    if paginado(filesize, reclen) and registros_por_pagina(reclen) < 1:
        raise FormatoNaoSuportado(
            f"{tabela}: layout paginado com reclen {reclen} maior que a pagina ({PAGINA}) — "
            f"nao sabemos onde cada registro comeca. Nao suportado.")
    if (filesize - HEADER) < reclen:
        raise FormatoNaoSuportado(
            f"{tabela}: nenhum registro inteiro cabe (tamanho {filesize}, header {HEADER}, reclen "
            f"{reclen}) — vazio ou layout nao suportado.")
    campos = []
    idx = 1
    while True:
        base = DESC_OFF + (idx - 1) * DESC_SZ
        d = dat[base:base + DESC_SZ]
        off = int.from_bytes(d[0:2], "little")
        length = d[3]
        tipo = d[4]
        dec = (d[2] & 0x0F) * 2
        # fim da tabela de campos: sem nome no .FD e descritor zerado
        if idx not in fd_names and (off == 0 or length == 0):
            break
        if tipo not in (TIPO_ASC, TIPO_NUM, TIPO_DATE):
            raise FormatoNaoSuportado(
                f"{tabela}: campo {idx} ({fd_names.get(idx, '?')}) tem tipo desconhecido (b4={tipo}) — "
                f"so ASCII/NUM/DATE suportados.")
        campos.append((idx, fd_names.get(idx, f"CAMPO_{idx}"), off, length, tipo, dec))
        idx += 1
        if idx > 512:
            break
    if not campos:
        raise FormatoNaoSuportado(f"{tabela}: nenhum campo reconhecido no header — layout nao suportado.")
    return reclen, campos


def _read_meta_only(base_dir: str, name: str):
    """(reclen, campos) lendo só a fatia de header do .dat (evita ler 100+ MB só p/ metadados)."""
    datp = _find(os.path.join(base_dir, "Data"), name, [".dat", ".DAT"])
    if not datp:
        raise FileNotFoundError(f"{name}.dat nao encontrado")
    filesize = os.path.getsize(datp)
    with open(datp, "rb") as f:
        head = f.read(DESC_OFF + 512 * DESC_SZ + 16)
    fd_names = _parse_fd(os.path.join(base_dir, "DDSrc"), name)
    return table_meta(head, fd_names, filesize, name)


def column_types(base_dir: str, name: str) -> dict:
    """{coluna_lowercase: tipo_dlt} — p/ hints do dlt (materializa até colunas 100% nulas)."""
    _reclen, campos = _read_meta_only(base_dir, name)
    out = {}
    for _idx, nome, _off, _len, tipo, dec in campos:
        if tipo == TIPO_NUM:
            out[nome.lower()] = "decimal" if dec else "bigint"
        elif tipo == TIPO_DATE:
            out[nome.lower()] = "date"
        else:
            out[nome.lower()] = "text"
    return out


def conferir_tipos_fd(base_dir: str, name: str, campos) -> list[str]:
    """Divergencias entre o tipo declarado no .FD e o tipo do header. -> lista de avisos.

    Duas fontes independentes descrevendo o mesmo campo. O header vence na decodificacao
    (o .FD e texto gerado e pode estar dessincronizado), mas divergir e sinal de que o
    descritor pode nao estar sendo lido onde pensamos — vale reportar, nao abortar.
    """
    fd_tipos = _parse_fd_tipos(os.path.join(base_dir, "DDSrc"), name)
    nomes = {TIPO_ASC: "texto", TIPO_NUM: "numero", TIPO_DATE: "data"}
    avisos = []
    for idx, nome, _off, _len, tipo, _dec in campos:
        declarado = fd_tipos.get(idx)
        if declarado is not None and declarado != tipo:
            avisos.append(
                f"{name}.{nome}: o .FD declara {nomes[declarado]} e o header diz "
                f"{nomes[tipo]}. Decodificado como {nomes[tipo]} (o header vence).")
    return avisos


# Faixa em que uma data decodificada e plausivel. Fora dela, o mais provavel e que o campo
# nao seja data ou que o registro esteja desalinhado — nao uma data exotica de verdade.
ANO_MIN_PLAUSIVEL = 1970
ANOS_FUTURO_PLAUSIVEL = 1


def _data_implausivel(d) -> bool:
    hoje = datetime.date.today()
    return d.year < ANO_MIN_PLAUSIVEL or d.year > hoje.year + ANOS_FUTURO_PLAUSIVEL


def read_table(base_dir: str, name: str):
    """Le uma tabela DataFlex no layout PROVADO. Retorna (colunas, gerador_de_linhas).

    base_dir: pasta com Data/ e DDSrc/. Cada linha e um dict {coluna: valor}.
    Registros totalmente zerados (slots livres) sao pulados.

    O layout vem de df_layout — header por consenso da base, pagina provada por tabela —
    em vez de assumido. Levanta df_layout.TabelaVazia para tabela sem registro e
    df_layout.LayoutIndeterminado para arquivo que nao se prova legivel.

    O gerador expoe `linhas.avisos` (lista) e `linhas.datas_implausiveis` (contador),
    preenchidos durante a leitura — o chamador reporta o que quiser.
    """
    datp = _find(os.path.join(base_dir, "Data"), name, [".dat", ".DAT"])
    if not datp:
        raise FileNotFoundError(f"{name}.dat nao encontrado em {base_dir}\\Data")

    lay = layout_da_tabela(base_dir, name)     # prova o layout antes de ler o arquivo todo
    dat = open(datp, "rb").read()
    fd_names = _parse_fd(os.path.join(base_dir, "DDSrc"), name)
    reclen, campos = table_meta(dat, fd_names, len(dat), name)
    colunas = [c[1] for c in campos]

    # `avisos` chega na caixa de dialogo de quem opera a conversao: sem percentual, sem
    # nome de constante. `avisos_tecnicos` sai no stdout, para diagnostico.
    avisos = conferir_tipos_fd(base_dir, name, campos)
    avisos_tecnicos = []
    if lay.get("aviso"):
        avisos.insert(0, lay["aviso"])
    if lay.get("aviso_tecnico"):
        avisos_tecnicos.append(lay["aviso_tecnico"])

    def linhas():
        for o in df_layout.offsets_candidato(len(dat), reclen, lay["header"], lay["pagina"]):
            rec = dat[o:o + reclen]
            if not any(rec):
                continue  # slot livre
            row = {}
            for _idx, nome, off, length, tipo, dec in campos:
                v = _decode(rec[off - 1:off - 1 + length], tipo, dec)
                if tipo == TIPO_DATE and v is not None and _data_implausivel(v):
                    linhas.datas_implausiveis += 1
                row[nome] = v
            yield row

    linhas.avisos = avisos
    linhas.avisos_tecnicos = avisos_tecnicos
    linhas.datas_implausiveis = 0
    linhas.layout = lay
    return colunas, linhas


# --------------------------------------------------------------- self-check
def _selfcheck():
    base = r"C:\Users\Mateus Borges\Downloads\Issues\8631_MercadoTina_Conversao_Protheus\Origem Protheus"
    import sys
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    # CLIENTES: 1o registro CONSUMIDOR, DT_CADASTRO ~1999-12, 207 registros
    cols, gen = read_table(base, "CLIENTES")
    rows = list(gen())
    assert "NOME" in cols and "DT_CADASTRO" in cols, cols[:5]
    assert rows[0]["NOME"] == "CONSUMIDOR", rows[0]["NOME"]
    dtc = rows[0]["DT_CADASTRO"]
    assert dtc and dtc.year == 1999, dtc
    print(f"CLIENTES: {len(rows)} linhas | [0] NOME={rows[0]['NOME']!r} DT_CADASTRO={dtc}")

    # PRODUTOS: HIDRATANTE MONANGE com PRECO1 = 6.99
    cols, gen = read_table(base, "PRODUTOS")
    prod = next(r for r in gen() if r.get("NOME", "").startswith("HIDRATANTE MONANGE"))
    assert prod["PRECO1"] == decimal.Decimal("6.99"), prod["PRECO1"]
    print(f"PRODUTOS: NOME={prod['NOME']!r} PRECO1={prod['PRECO1']} UN={prod.get('UN')!r}")

    # cidades: NOVA BRASILANDIA, MUNICIPIO codigo IBGE
    cols, gen = read_table(base, "cidades")
    cids = list(gen())
    nb = next(r for r in cids if "NOVA BRASIL" in (r.get("NOME_MUNIC") or ""))
    assert nb["MUNICIPIO"] == 1100148, nb["MUNICIPIO"]  # IBGE 7 digitos (top nibble = flag, mascarado)
    print(f"cidades: {len(cids)} linhas | ex NOME_MUNIC={nb['NOME_MUNIC']!r} MUNICIPIO={nb['MUNICIPIO']} UF={nb['UF']!r}")

    # SECAO: tabela PAGINADA (reclen 85, resto != 0). Lida como contigua, as 5 primeiras saem
    # certas e as 18 seguintes saem lixo — o caso tem que cobrir DEPOIS da 1a fronteira de pagina.
    cols, gen = read_table(base, "SECAO")
    secs = list(gen())
    assert len(secs) == 23, len(secs)
    codigos = [r["CODIGO"] for r in secs]
    assert codigos == list(range(1, 24)), codigos
    assert secs[0]["NOME"] == "ACOUGUE", secs[0]["NOME"]
    assert secs[6]["NOME"] == "CONGELADOS", secs[6]["NOME"]      # pagina 2 — o que o bug corrompia
    assert secs[22]["NOME"] == "ELASTICO LATEX", secs[22]["NOME"]
    print(f"SECAO (paginada): {len(secs)} linhas | [6] NOME={secs[6]['NOME']!r} "
          f"[22] NOME={secs[22]['NOME']!r} | CODIGO 1..23 sequencial")

    print("\nOK — self-check passou (datas, decimais, IBGE, contagem, layout paginado).")


if __name__ == "__main__":
    _selfcheck()
