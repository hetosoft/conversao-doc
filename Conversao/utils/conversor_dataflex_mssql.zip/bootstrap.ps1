# Bootstrap do conversor DataFlex -> SQL Server.
# Garante o uv (via winget, latest) e roda o conversor_dataflex_mssql.py repassando os argumentos
# recebidos do app (Sol.NET). O Sol.NET abre esta janela user-facing: o operador acompanha o
# progresso e le o resumo no fim -- por isso o Read-Host segura a janela ate ele fechar.
# O exit code e propagado p/ o Sol.NET ramificar.
#
# Diferente do conversor Access: a LEITURA da origem e um parser proprio em Python (df_reader.py,
# no mesmo .zip) -- NAO instala driver ODBC DataFlex (nenhum e gratis sem licenca por-maquina),
# nem eleva por causa disso. O destino (dlt -> SQL Server) usa o ODBC Driver 17/18 for SQL Server,
# que se espera presente na maquina de conversao (client tools do SQL Server).
#
# Compativel com Windows PowerShell 5.1: so winget + recarga de PATH.

$ErrorActionPreference = 'Stop'
$code = 0

try
{
    $PyScript = Join-Path $PSScriptRoot 'conversor_dataflex_mssql.py'
    $Reader = Join-Path $PSScriptRoot 'df_reader.py'
    if (-not (Test-Path $PyScript))
    {
        throw "conversor_dataflex_mssql.py nao encontrado em $PSScriptRoot"
    }
    $Layout = Join-Path $PSScriptRoot 'df_layout.py'
    if (-not (Test-Path $Layout))
    {
        throw "df_layout.py (prova do layout do .dat) nao encontrado em $PSScriptRoot"
    }
    if (-not (Test-Path $Reader))
    {
        throw "df_reader.py (parser da origem) nao encontrado em $PSScriptRoot"
    }

    # uv via winget (sem pin -> latest). Idempotente: instala so se ausente. O winget cria o shim
    # em %LOCALAPPDATA%\Microsoft\WinGet\Links, que so entra no PATH de sessoes novas -> recarrega o
    # PATH (Machine+User) para enxergar o uv recem-instalado ainda nesta sessao.
    if (-not (Get-Command uv -ErrorAction SilentlyContinue))
    {
        Write-Host 'uv nao encontrado. Instalando via winget...'
        winget install -e --id astral-sh.uv --silent --disable-interactivity --accept-package-agreements --accept-source-agreements
        $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                    [Environment]::GetEnvironmentVariable('Path', 'User')
    }

    # @args = argumentos do app (--dataflex-dir, --server, --db, --user, --senha, --tables, --limit),
    # repassados ao uv via splatting. O uv provisiona Python + deps (dlt[mssql], pyodbc) na 1a execucao.
    #
    # Caminho rapido (ADBC/arrow) so em SQL Server REAL + SQL auth: injeta pyarrow+adbc-driver-manager
    # via --with (env separado). LocalDB/instancia nomeada/Trusted roda no env limpo -> insert_values
    # (o ADBC nao conecta em LocalDB). Detecta pelo --server e --user recebidos.
    $srv = ''; $usr = ''
    for ($i = 0; $i -lt $args.Count; $i++)
    {
        if ($args[$i] -eq '--server') { $srv = [string]$args[$i + 1] }
        if ($args[$i] -eq '--user') { $usr = [string]$args[$i + 1] }
    }
    $servidorReal = ($usr -ne '') -and ($srv -notmatch '(?i)localdb') -and ($srv -notmatch '\\')

    if ($servidorReal)
    {
        Write-Host 'Servidor real + SQL auth: usando caminho rapido (ADBC/arrow).'
        uv run --with pyarrow --with adbc-driver-manager $PyScript @args
    }
    else
    {
        uv run $PyScript @args
    }
    $code = $LASTEXITCODE
}
catch
{
    Write-Host ('ERRO no bootstrap da conversao: ' + $_.Exception.Message)
    $code = 1
}
finally
{
    Write-Host ''
    Read-Host 'Processo finalizado. Pressione Enter para fechar'
}
exit $code
