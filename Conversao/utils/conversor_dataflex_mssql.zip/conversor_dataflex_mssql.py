# /// script
# requires-python = ">=3.12"
# dependencies = ["dlt[mssql]>=1.19", "pyodbc"]
# ///
"""Conversor DataFlex (embedded .dat) -> SQL Server, autocontido.

Le a origem com um parser proprio em Python (df_reader.py, mesma pasta — ZERO driver ODBC
DataFlex, nenhum e gratuito sem licenca por-maquina) e carrega cada tabela no SQL Server via
`dlt.destinations.mssql` (reusa a metade destino do conversor Access). O banco de destino e
criado do ZERO (CREATE DATABASE) se nao existir. Nomes de tabela/coluna = crus do DataFlex.

  uv run conversor_dataflex_mssql.py --dataflex-dir <pasta com Data\\ e DDSrc\\> \
      --server <host[,porta] | (localdb)\\MSSQLLocalDB> --db <banco> \
      [--user <u> --senha <p>]   # sem --user => Trusted_Connection (Windows auth)
      [--tables T1,T2,...] [--limit N]

Disparado pela aba "Configuracao DataFlex" do conversor Sol.NET (via bootstrap.ps1).
"""
import argparse
import glob
import importlib.util
import os
import shutil
import subprocess
import sys
import decimal
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # p/ achar df_reader no .zip
import pyodbc
import dlt

from df_reader import (read_table, column_types, paginado, registros_por_pagina,
                       HEADER, RECLEN_OFF, ANO_MIN_PLAUSIVEL)
from df_layout import TabelaVazia

# dlt monta SERVER="host,port" fixo (mssql/configuration.py); instancia nomeada (LocalDB) nao tem
# porta. Patch: sem porta quando o host e instancia nomeada (contem \ ou (localdb)).
from dlt.destinations.impl.mssql.configuration import MsSqlCredentials
_orig_dsn = MsSqlCredentials.get_odbc_dsn_dict
def _dsn_named_instance(self):
    d = _orig_dsn(self)
    h = self.host or ""
    if "\\" in h or "(localdb)" in h.lower():
        d["SERVER"] = h
    return d
MsSqlCredentials.get_odbc_dsn_dict = _dsn_named_instance

DRIVER = "ODBC Driver 17 for SQL Server"

# tabela de controle escrita no destino a cada run: o que ficou de fora e por que. A aba
# "Configuracao DataFlex" le daqui pra avisar o usuario (o shell-out e fire-and-forget, o app
# nao ve o stdout). Prefixo _ marca que nao e tabela da origem.
TABELA_DIAGNOSTICO = "_conversao_ignoradas"

# nao acumula pacote de carga em disco; corta o ruido INFO do dlt (hints ja evitam os warnings de tipo).
os.environ["LOAD__DELETE_COMPLETED_JOBS"] = "true"
os.environ.setdefault("RUNTIME__LOG_LEVEL", "WARNING")


def _pick_driver() -> str:
    drivers = set(pyodbc.drivers())
    for d in ("ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server"):
        if d in drivers:
            return d
    raise SystemExit("Nenhum ODBC Driver 17/18 for SQL Server instalado.")


def odbc_str(server: str, db: str, user: str | None, senha: str | None, driver: str) -> str:
    s = f"DRIVER={{{driver}}};SERVER={server};DATABASE={db};TrustServerCertificate=yes;"
    if user:
        s += f"UID={user};PWD={senha};"
    else:
        s += "Trusted_Connection=yes;"
    return s


def dlt_dest(server: str, db: str, user: str | None, senha: str | None, driver: str) -> dict:
    query = {"TrustServerCertificate": "yes"}
    if user:
        host, _, porta = server.partition(",")
        return {"drivername": "mssql", "host": host, "port": int(porta) if porta else 1433,
                "database": db, "username": user, "password": senha, "driver": driver, "query": query}
    query["trusted_connection"] = "yes"
    return {"drivername": "mssql", "host": server, "database": db,
            "username": "", "password": "", "driver": driver, "query": query}


def _adbc_env() -> bool:
    # True quando o env tem adbc-driver-manager. O bootstrap injeta (via --with) SO em servidor
    # real; LocalDB/Trusted roda em env limpo (sem pyarrow) -> dlt usa insert_values naturalmente.
    return importlib.util.find_spec("adbc_driver_manager") is not None


def _dbc_tem_mssql() -> bool:
    try:
        r = subprocess.run(["uv", "tool", "run", "dbc", "list"], capture_output=True, text=True, timeout=90)
        return r.returncode == 0 and "mssql" in (r.stdout or "").lower()
    except Exception:
        return False


def garantir_adbc() -> bool:
    # instala o driver ADBC do SQL Server (via dbc) se faltar -> dlt usa carga em lote (arrow). Best-effort.
    if _dbc_tem_mssql():
        return True
    try:
        subprocess.run(["uv", "tool", "run", "dbc", "install", "mssql"], timeout=600)
    except Exception:
        return False
    return _dbc_tem_mssql()


def criar_db_do_zero(server, db, user, senha, driver) -> bool:
    """Conecta no master (autocommit) e cria o banco se nao existir. Retorna True se criou."""
    cn = pyodbc.connect(odbc_str(server, "master", user, senha, driver), autocommit=True, timeout=15)
    try:
        cur = cn.cursor()
        if cur.execute("SELECT COUNT(*) FROM sys.databases WHERE name = ?", db).fetchone()[0]:
            return False
        cur.execute(f"CREATE DATABASE [{db}]")
        return True
    finally:
        cn.close()


def registrar_diagnostico(cn, linhas) -> None:
    """Recria dbo._conversao_ignoradas no destino com uma linha por tabela que ficou de fora.

    linhas: iteravel de (tabela, tipo, motivo). tipo e IGNORADA (nao reconhecida no pre-filtro),
    FALHA (erro na carga) ou AUSENTE (origem sem linhas -> o dlt nao materializa a tabela).
    Recriada a cada run: o conteudo descreve SEMPRE a ultima conversao, nunca acumula historico.
    """
    cur = cn.cursor()
    cur.execute(f"IF OBJECT_ID('dbo.[{TABELA_DIAGNOSTICO}]', 'U') IS NOT NULL "
                f"DROP TABLE dbo.[{TABELA_DIAGNOSTICO}]")
    cur.execute(f"CREATE TABLE dbo.[{TABELA_DIAGNOSTICO}] ("
                "TABELA NVARCHAR(128) NOT NULL, TIPO NVARCHAR(20) NOT NULL, "
                "MOTIVO NVARCHAR(1000) NULL, DATA_CONVERSAO DATETIME2 NOT NULL DEFAULT SYSDATETIME())")
    for tabela, tipo, motivo in linhas:
        cur.execute(f"INSERT INTO dbo.[{TABELA_DIAGNOSTICO}] (TABELA, TIPO, MOTIVO) VALUES (?, ?, ?)",
                    tabela[:128], tipo[:20], (motivo or "")[:1000])
    cn.commit()


def conferir_somas(cur, name: str, esperado: dict):
    """Compara a soma de cada coluna numerica: origem (acumulada na carga) x destino (SUM).

    -> [(coluna, soma_origem, soma_destino)] das que divergem. Lista vazia = tudo bate.

    A soma da origem vem da PROPRIA passagem que carregou os dados, entao nao ha segundo
    parse — e, por isso mesmo, ela nao prova a interpretacao da origem, so o transporte
    (ver o comentario na verificacao de integridade).

    A comparacao e exata: soma de decimal/bigint nao deveria mudar entre origem e destino,
    e tolerancia aqui esconderia justamente o truncamento que queremos pegar. Coluna que o
    destino nao tem (o dlt nao materializa o que nunca recebeu valor) e ignorada — a
    ausencia dela ja e reportada por outro caminho.
    """
    tabela = name.lower()
    presentes = {r[0].lower() for r in cur.execute(
        "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
        "WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME=?", tabela).fetchall()}
    alvo = [c for c in esperado if c in presentes]
    if not alvo:
        return []

    colunas = ", ".join(f"SUM(CAST([{c}] AS DECIMAL(38,10)))" for c in alvo)
    linha = cur.execute(f"SELECT {colunas} FROM dbo.[{tabela}]").fetchone()

    divergentes = []
    for c, valor_destino in zip(alvo, linha):
        origem = decimal.Decimal(esperado[c])
        destino = decimal.Decimal(valor_destino) if valor_destino is not None else decimal.Decimal(0)
        if origem != destino:
            divergentes.append((c, origem, destino))
    return divergentes


def tabelas_validas(dataflex_dir: str):
    """([tabelas validas], [(tabela, motivo) ignoradas]). Fail-loud: `.dat` que nao batem o formato
    DataFlex esperado (reclen fora de faixa, arquivo menor que o header, nenhum registro inteiro)
    sao reportados com o motivo, nao sumidos em silencio — assim uma base de versao/variante nao
    suportada fica visivel.

    Layout paginado NAO desqualifica a tabela: o leitor sabe percorrer as duas formas
    (ver df_reader.offsets). So o que ele nao sabe posicionar e recusado.
    """
    validas, ignoradas, vistos = [], [], set()
    for datp in sorted(glob.glob(os.path.join(dataflex_dir, "Data", "*.dat")) +
                       glob.glob(os.path.join(dataflex_dir, "Data", "*.DAT"))):
        nome = os.path.splitext(os.path.basename(datp))[0]
        if nome.lower() in vistos:
            continue
        vistos.add(nome.lower())
        try:
            fs = os.path.getsize(datp)
            with open(datp, "rb") as f:
                head = f.read(RECLEN_OFF + 2)
            reclen = int.from_bytes(head[RECLEN_OFF:RECLEN_OFF + 2], "little")
            if not 0 < reclen <= 65535:
                ignoradas.append((nome, f"reclen invalido ({reclen})"))
            elif fs <= HEADER:
                ignoradas.append((nome, f"menor que o header ({fs}B)"))
            elif paginado(fs, reclen) and registros_por_pagina(reclen) < 1:
                ignoradas.append((nome, f"layout paginado com reclen {reclen} maior que a pagina"))
            elif (fs - HEADER) < reclen:
                ignoradas.append((nome, f"nenhum registro inteiro cabe (reclen {reclen}, tamanho {fs})"))
            else:
                validas.append(nome)
        except Exception as e:
            ignoradas.append((nome, f"{type(e).__name__}: {e}"))
    return validas, ignoradas


def recurso(dataflex_dir: str, name: str, limit: int | None, counts: dict,
            somas: dict, avisos: dict):
    # hints de coluna a partir do descritor: materializa toda coluna (mesmo 100% nula) com o tipo certo.
    tipos = column_types(dataflex_dir, name)
    hints = {c: {"data_type": t} for c, t in tipos.items()}
    numericas = [c for c, t in tipos.items() if t in ("decimal", "bigint")]

    def gen(dataflex_dir=dataflex_dir, name=name, limit=limit):
        try:
            cols, g = read_table(dataflex_dir, name)
        except TabelaVazia:
            # Tabela sem registro nao e falha: 135 das 171 da MercadoTina sao features que o
            # cliente nunca usou. Sem este ramo a excecao sobe pelo gerador do dlt e a carga
            # inteira vira PipelineStepFailed — a tabela some do destino por um motivo que nao
            # existe. Zero linhas e a resposta certa: o dlt nao materializa a tabela e a
            # verificacao ja a reporta como AUSENTE.
            counts[name] = 0
            somas[name] = {}
            return
        # o leitor devolve as colunas no caso original; o destino usa minusculo
        por_minusculo = {c.lower(): c for c in cols}
        acumulado = {c: decimal.Decimal(0) for c in numericas if c in por_minusculo}
        n = 0
        for i, row in enumerate(g()):
            if limit and i >= limit:
                break
            n += 1
            for c in acumulado:
                v = row.get(por_minusculo[c])
                if v is not None:
                    acumulado[c] += decimal.Decimal(v)
            yield row
        counts[name] = n  # contagem da origem capturada na propria carga (sem 2o parse)
        somas[name] = acumulado
        if getattr(g, "avisos", None):
            avisos[name] = list(g.avisos)
        if getattr(g, "datas_implausiveis", 0):
            avisos.setdefault(name, []).append(
                f"{name}: {g.datas_implausiveis} data(s) fora da faixa esperada — confira se "
                f"o campo e data mesmo.")
        # detalhe numerico so no stdout: nao entra na tabela de diagnostico, que alimenta a
        # caixa de dialogo da aba
        for tecnico in getattr(g, "avisos_tecnicos", []):
            print(f"    detalhe: {tecnico}", flush=True)

    return dlt.resource(gen, name=name.lower(), write_disposition="replace", columns=hints)


def main():
    ap = argparse.ArgumentParser(description="Converte DataFlex (.dat) -> SQL Server")
    ap.add_argument("--dataflex-dir", required=True, help="pasta com subpastas Data\\ e DDSrc\\")
    ap.add_argument("--server", required=True, help="host[,porta] ou (localdb)\\MSSQLLocalDB")
    ap.add_argument("--db", required=True, help="banco de destino (criado se nao existir)")
    ap.add_argument("--user", default=None, help="usuario SQL; ausente => Trusted_Connection")
    ap.add_argument("--senha", default=None)
    ap.add_argument("--tables", default=None, help="subconjunto CSV (default: todas as validas)")
    ap.add_argument("--limit", type=int, default=None, help="limite de linhas por tabela (smoke)")
    args = ap.parse_args()

    driver = _pick_driver()
    base = args.dataflex_dir
    if not os.path.isdir(os.path.join(base, "Data")):
        raise SystemExit(f"{base} nao tem subpasta Data\\")

    print(f"Conversao DataFlex -> SQL Server | destino: [{args.db}] em {args.server}")
    # servidor real + SQL auth + env com adbc (bootstrap injetou) -> caminho rapido (ADBC/arrow).
    # instala o driver ADBC (garantir_adbc). LocalDB/Trusted -> env limpo -> insert_values.
    servidor_nomeado = ("(localdb)" in args.server.lower()) or ("\\" in args.server)
    usar_adbc = bool(args.user) and not servidor_nomeado and _adbc_env() and garantir_adbc()
    print(f"Carga via {'ADBC/arrow (lote, rapido)' if usar_adbc else 'insert_values (pyodbc)'}.")
    criado = criar_db_do_zero(args.server, args.db, args.user, args.senha, driver)
    print(f"Banco [{args.db}] {'criado do zero' if criado else 'ja existia'}.")

    if args.tables:
        tabelas = [t.strip() for t in args.tables.split(",") if t.strip()]
        ignoradas = []
    else:
        tabelas, ignoradas = tabelas_validas(base)
    print(f"{len(tabelas)} tabela(s) a converter.")
    if ignoradas:
        print(f"{len(ignoradas)} arquivo(s) .dat ignorado(s) (nao reconhecidos como tabela DataFlex suportada):")
        for n, motivo in ignoradas[:50]:
            print(f"  - {n}: {motivo}")
        if len(ignoradas) > 50:
            print(f"  ... e mais {len(ignoradas) - 50}.")
    print()

    dest = dlt_dest(args.server, args.db, args.user, args.senha, driver)
    dest_factory = dlt.destinations.mssql(credentials=dest)
    state_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_dlt_state")
    shutil.rmtree(state_root, ignore_errors=True)  # estado dlt efemero: cada run comeca limpo

    ok, falhas, t0, counts = 0, [], time.perf_counter(), {}
    somas, avisos_leitura = {}, {}
    for i, name in enumerate(tabelas, 1):
        try:
            print(f"[{i}/{len(tabelas)}] {name}: carregando...", flush=True)
            # pipeline PROPRIA por tabela (nome + pasta de estado isolados): uma carga que falha
            # nao contamina as seguintes (o problema do pacote de carga preso na pipeline compartilhada).
            pipe = dlt.pipeline(pipeline_name=f"cdf_{name.lower()}"[:60],
                                destination=dest_factory, dataset_name="dbo",
                                pipelines_dir=os.path.join(state_root, name.lower()))
            pipe.run(recurso(base, name, args.limit, counts, somas, avisos_leitura))
            ok += 1
        except Exception as e:
            falhas.append((name, f"{type(e).__name__}: {e}"))
            print(f"[{i}/{len(tabelas)}] {name}: FALHOU ({type(e).__name__})", flush=True)
    print(f"\nCarga: {ok}/{len(tabelas)} ok em {time.perf_counter()-t0:.0f}s. "
          f"{len(falhas)} falha(s).")
    for n, msg in falhas:
        print(f"  FALHA {n}: {msg[:160]}")

    # --- verificacao de integridade: contagem e SOMA origem x destino ---
    #
    # As duas verificacoes provam coisas diferentes, e nenhuma substitui a outra:
    #
    #   contagem  -> prova que nao perdemos nem duplicamos LINHA no transporte.
    #   soma      -> prova que nao corrompemos VALOR no transporte (truncamento de decimal,
    #                overflow, conversao de tipo errada no destino).
    #
    # O que NENHUMA das duas prova e a INTERPRETACAO da origem: as duas leem a origem pela
    # mesma passagem do parser, entao um layout mal escolhido sai igual nos dois lados e
    # passa. Quem cobre isso e a prova de layout do df_layout, feita antes de ler.
    print("\nVerificacao de integridade (origem x destino):")
    cn = pyodbc.connect(odbc_str(args.server, args.db, args.user, args.senha, driver), timeout=30)
    cur = cn.cursor()
    div = 0
    ausentes = []
    somas_ruins = []
    nomes_falhos = {n for n, _m in falhas}
    for name in tabelas:
        try:
            lo = counts.get(name)
            r = cur.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME=?",
                            name.lower()).fetchone()
            if not r or r[0] == 0:
                ld = None
            else:
                ld = cur.execute(f"SELECT COUNT(*) FROM dbo.[{name.lower()}]").fetchone()[0]
            if name in nomes_falhos:
                # a carga levantou excecao: nao ha o que comparar. Sem este ramo, origem=destino=None
                # daria "OK" e a verificacao afirmaria o contrario do que aconteceu.
                status = "FALHOU"
            else:
                status = "OK" if ld == lo else ("VAZIA" if lo in (0, None) and ld is None else "DIVERGE")
            if status == "DIVERGE":
                div += 1
            if ld is None and status != "DIVERGE" and name not in nomes_falhos:
                # origem sem linhas: o dlt nao cria tabela sem dado, mesmo com hints de coluna. O
                # de-para que consultar esta tabela quebra com "Invalid object name" — registrar.
                ausentes.append((name, "AUSENTE", f"origem sem linhas ({lo}) — nao materializada no destino"))
            # soma das colunas numericas: pega corrupcao de VALOR que a contagem nao ve
            colunas_divergentes = []
            if status == "OK" and somas.get(name):
                colunas_divergentes = conferir_somas(cur, name, somas[name])
                if colunas_divergentes:
                    status = "SOMA!="
                    div += 1
                    somas_ruins.append((name, colunas_divergentes))

            so = str(lo) if lo is not None else "—"
            sd = str(ld) if ld is not None else "—"
            print(f"  {status:8} {name:14} origem={so:>7} destino={sd:>7}"
                  + (f"  soma difere em {len(colunas_divergentes)} coluna(s)"
                     if colunas_divergentes else ""))
            for col, vo, vd in colunas_divergentes[:5]:
                print(f"           {col}: origem={vo} destino={vd}")
        except Exception as e:
            print(f"  ERRO    {name:14} {type(e).__name__}: {str(e)[:80]}")

    if avisos_leitura:
        print(f"\nAvisos de leitura ({sum(len(v) for v in avisos_leitura.values())}) — o leitor "
              f"converteu, mas nao pode provar tudo:")
        for tabela, msgs in avisos_leitura.items():
            for m in msgs:
                print(f"  - {m}")

    diagnostico = ([(n, "IGNORADA", m) for n, m in ignoradas] +
                   [(n, "FALHA", m) for n, m in falhas] + ausentes +
                   [(n, "SOMA", "soma difere em: " + ", ".join(
                       f"{c} (origem {vo}, destino {vd})" for c, vo, vd in cols))
                    for n, cols in somas_ruins] +
                   [(n, "AVISO", m) for n, msgs in avisos_leitura.items() for m in msgs])
    try:
        registrar_diagnostico(cn, diagnostico)
        print(f"\nDiagnostico em dbo.{TABELA_DIAGNOSTICO}: {len(diagnostico)} registro(s) "
              f"({len(ignoradas)} ignorada(s), {len(falhas)} falha(s), {len(ausentes)} sem linhas "
              f"na origem, {len(somas_ruins)} com soma divergente, "
              f"{sum(len(v) for v in avisos_leitura.values())} aviso(s) de leitura).")
    except Exception as e:
        print(f"\nAVISO: nao gravou dbo.{TABELA_DIAGNOSTICO}: {type(e).__name__}: {e}")
    cn.close()
    print(f"\nFim. {ok} tabela(s) carregada(s), {div} divergencia(s) "
          f"({len(somas_ruins)} de soma).")


if __name__ == "__main__":
    main()
