# /// script
# requires-python = ">=3.10"
# ///
"""Descoberta e prova do layout fisico dos .dat de uma base DataFlex.

Por que este modulo existe
--------------------------
O leitor original assumia header 3072 e pagina 512, e decidia entre layout contiguo e
paginado por um unico sinal: o resto de (filesize - header) % reclen. Isso funcionou na
MercadoTina, mas tem um modo de falha ruim: ler contiguo uma tabela paginada NAO levanta
erro — produz dado plausivel e errado a partir da segunda pagina, e a verificacao por
contagem nao pega, porque origem e destino saem da mesma leitura.

Aqui o layout deixa de ser assumido e passa a ser PROVADO, por invariantes que os proprios
bytes fornecem:

  - Nibble BCD: num campo numerico/data o valor e BCD, entao todo nibble tem de ser 0-9
    (menos o top nibble do byte 0, que carrega flag/sinal). 'A'-'F' ali so aparece por
    desalinhamento.
  - Byte ASCII: num campo de texto de largura fixa os bytes sao imprimiveis ou padding.
  - Chave duplicada: desalinhamento faz o padding 0x20 0x20 virar o numero 2020, repetido —
    o primeiro campo sai duplicado em massa. Este sinal existe porque os dois primeiros nao
    pegam esse caso: os nibbles de 0x20 sao 2 e 0, ambos validos como BCD.

Nenhum sinal serve sozinho, e a medicao na base inteira da MercadoTina diz quanto (14
tabelas com rival de verdade, "acertos/erros" do layout certo contra o melhor rival):

    bcd sozinho              7 / 7     moeda
    ascii sozinho           10 / 4
    chave duplicada         13 / 1     o mais forte isolado
    max(bcd, ascii)          9 / 5     erra em 5 tabelas
    max(bcd, ascii, dup)    14 / 0     e este que usamos

RELATIVO, NAO ABSOLUTO — a lição que custou uma tentativa
---------------------------------------------------------
Chave duplicada em massa e LEGITIMA numa tabela filha, onde o primeiro campo e chave
estrangeira e nao chave: na MercadoTina, `dependen` da 91%, `os` 75%, `emissorx` 60% — no
layout CERTO. E o bcd chega a 4,55% no layout certo (`usuarios`). Portanto nenhum dos tres
sinais tem significado absoluto confiavel, e a primeira versao deste modulo errava ao usar
um limiar absoluto como gate: ele rejeitava dado bom.

O que se sustenta e a comparacao entre candidatos da MESMA tabela: no `emissorx`, o layout
certo da 60,25% de chave duplicada e o rival da 76,25%. A escolha e por comparacao; o unico
limite absoluto que resta e um backstop frouxo de "isto nao e DataFlex", e ele nao olha
chave duplicada.

Margem apertada avisa, nao aborta: a margem do layout certo sobre o rival vai de 1,27x
(`emissorx`) a mais de 100x. Exigir um fator fixo de 2x rejeitaria `emissorx` e `NCM`, que
estao certos. Entao exigimos apenas vitoria ESTRITA, e abaixo de 2x emitimos aviso nomeando
a tabela — o objetivo e nao mentir, nao prometer ler qualquer DataFlex.

Duas escalas, e a distincao importa
-----------------------------------
O **header** e constante do FORMATO: e onde acabam os metadados (reclen em 0x9A, tabela de
descritores em 0x2E0) e comecam os dados. Vale para a base inteira, nao por tabela. Descobri-lo
por tabela foi o erro da primeira tentativa: candidatos de header fabricam rivais falsos.
    - Um header MAIOR que o real acerta o score lendo so a cauda do arquivo: no FORMA da
      MercadoTina, header 4608 sai com 0,00% de invalidos porque explica 3 dos 17 registros.
    - Um header MENOR cuja diferenca e multiplo da pagina descreve a MESMA grade: header 1024
      com pagina 512 le exatamente o que header 3072 le (2048 = 4 x 512), e as paginas extras
      caem como slots vazios. Nao e rival, e a mesma leitura.
Por isso o header sai de UM consenso entre varias tabelas da base.

A **pagina** varia por tabela (uma tabela com reclen > pagina nao pode ser paginada), e e
exatamente a decisao que o bug errava. Com o header fixo, contiguo x paginado se decide por
score com margem exigida.

Cobertura nao serve de critério: o layout contiguo sempre implica MAIS registros que o
paginado, porque nao desperdica o padding do fim de cada pagina. No NCM da MercadoTina o
contiguo implica 15.242 slots contra 15.180 do paginado — escolher por cobertura erraria.

Limite honesto
--------------
Os candidatos estao ancorados no unico export que conhecemos (MercadoTina). Uma versao de
DataFlex que nao guarde o reclen em 0x9A, ou que comprima os registros, cai no caminho de
falha ruidosa — nao no de dado errado. Fechar esse buraco exige uma segunda base de amostra.
"""
import os

HEADER_OBSERVADO = 0x0C00   # 3072 — o unico header visto até hoje
GRADE_HEADER = 0x200        # headers candidatos caem na grade de 512B
DESC_OFF = 0x2E0            # tabela de descritores — piso do header

# Candidatos de tamanho de pagina. None = sem paginacao (registros contiguos).
PAGINAS_CANDIDATAS = (None, 0x200, 0x400, 0x800, 0x1000)

# Abaixo deste fator a vitoria e apertada: seguimos, mas AVISAMOS nomeando a tabela, para
# que alguem confira a olho. Medido na MercadoTina, a margem do layout certo sobre o melhor
# rival vai de 1,27x (emissorx) a mais de 100x; exigir 2x rejeitaria dado bom.
FATOR_MARGEM_CONFORTAVEL = 2.0

# Backstop absoluto de "isto nao e DataFlex": aplicado SO a bcd/ascii, nunca a chave
# duplicada. Base da calibragem: no layout certo, o maior bcd/ascii observado na base
# inteira e 4,55% (usuarios); 20% deixa 4x de folga e ainda pega arquivo comprimido/Unicode.
LIMITE_BCD_ASCII = 0.20

AMOSTRA_REGISTROS = 400     # registros pontuados por candidato
MIN_REGISTROS = 4           # abaixo disto a amostra nao sustenta conclusao

TIPO_ASC, TIPO_NUM, TIPO_DATE = 0, 1, 2

# Bytes aceitos num campo ASCII de largura fixa: imprimiveis + padding.
_ASCII_OK = set(range(0x20, 0x7F)) | {0x00}


class LayoutIndeterminado(Exception):
    """Nenhum layout candidato se provou, ou mais de um empatou.

    Levantada em vez de escolher um palpite: dado plausivel e errado custa mais caro que
    uma conversao que para e diz qual tabela nao entendeu.
    """


class TabelaVazia(Exception):
    """A tabela nao tem nenhum registro preenchido, em nenhum layout candidato.

    Nao e falha de layout e nao merece alarme: sem registro nao ha o que decidir nem o que
    converter. Na MercadoTina 137 das 171 tabelas caem aqui (features que o cliente nunca
    usou) — trata-las como "layout indeterminado" afogaria em alarme falso os casos que
    realmente precisam de atencao.
    """


# --------------------------------------------------------------- offsets e score
def offsets_candidato(filesize: int, reclen: int, header: int, pagina: int | None):
    """Offsets dos slots de registro sob um layout candidato.

    pagina=None -> contiguo. Caso contrario os registros sao agrupados em paginas de
    `pagina` bytes e um registro nao cruza a fronteira (sobra padding no fim).
    """
    if header >= filesize or reclen < 1:
        return
    if pagina is None:
        for r in range((filesize - header) // reclen):
            yield header + r * reclen
        return
    por_pagina = pagina // reclen
    if por_pagina < 1:
        return
    p = 0
    while True:
        base = header + p * pagina
        if base >= filesize:
            return
        for i in range(por_pagina):
            o = base + i * reclen
            if o + reclen > filesize:
                return
            yield o
        p += 1


def _nibbles_invalidos(raw: bytes) -> tuple[int, int]:
    """(invalidos, total) nos nibbles BCD de um campo NUM/DATE.

    O top nibble do byte 0 e flag/sinal no DataFlex — nao entra na conta.
    """
    if not raw:
        return 0, 0
    ruins = 1 if (raw[0] & 0x0F) > 9 else 0
    total = 1
    for b in raw[1:]:
        total += 2
        if (b >> 4) > 9:
            ruins += 1
        if (b & 0x0F) > 9:
            ruins += 1
    return ruins, total


def _bytes_ascii_invalidos(raw: bytes) -> tuple[int, int]:
    """(invalidos, total) num campo ASCII de largura fixa."""
    if not raw:
        return 0, 0
    return sum(1 for b in raw if b not in _ASCII_OK), len(raw)


def _padding_nao_zero(dat: bytes, reclen: int, header: int, pagina: int,
                      paginas: int = 512) -> tuple[int, int]:
    """(bytes nao-zero, total) na cauda de cada pagina — a regiao que deveria ser padding.

    Invariante independente dos outros tres: se a pagina e a real, a sobra no fim dela
    (pagina % reclen bytes) nunca guarda dado, so preenchimento. Sob uma pagina ERRADA essa
    mesma regiao cai em cima de campos de um registro, e vem cheia de bytes nao-zero.

    E o unico sinal que separa dois tamanhos de pagina que pontuam identico nos outros tres
    — na MercadoTina, `etiqueta` empatava 512 contra 1024 em 0,72%.
    """
    sobra = pagina % reclen
    if sobra == 0 or pagina // reclen < 1:
        return 0, 0            # pagina multipla do registro: nao ha padding a conferir
    ruins = total = 0
    p = 0
    while p < paginas:
        base = header + p * pagina
        fim = base + pagina
        if fim > len(dat):
            break
        cauda = dat[fim - sobra:fim]
        ruins += sum(1 for b in cauda if b)
        total += sobra
        p += 1
    return ruins, total


def pontuar(dat: bytes, reclen: int, campos, header: int, pagina: int | None,
            amostra: int = AMOSTRA_REGISTROS) -> dict:
    """Pontua um layout candidato sobre uma amostra de registros.

    score = a PIOR das quatro fracoes de invalidos (bcd, ascii, chave duplicada, padding
    sujo). Um layout so passa quando os quatro concordam; cada um sozinho tem cego.
    """
    campo_chave = campos[0] if campos else None
    bcd_ruins = bcd_tot = asc_ruins = asc_tot = 0
    chaves = []
    vistos = com_conteudo = 0
    for o in offsets_candidato(len(dat), reclen, header, pagina):
        rec = dat[o:o + reclen]
        if len(rec) < reclen or not any(rec):
            continue           # slot livre ou cauda truncada
        vistos += 1
        tem_conteudo = False
        for _idx, _nome, off, length, tipo, _dec in campos:
            raw = rec[off - 1:off - 1 + length]
            if tipo in (TIPO_NUM, TIPO_DATE):
                r, t = _nibbles_invalidos(raw)
                bcd_ruins += r
                bcd_tot += t
                if any(b for b in raw):
                    tem_conteudo = True          # numero diferente de zero
            else:
                r, t = _bytes_ascii_invalidos(raw)
                asc_ruins += r
                asc_tot += t
                if any(0x21 <= b <= 0x7E for b in raw):
                    tem_conteudo = True          # texto imprimivel de verdade
        if tem_conteudo:
            com_conteudo += 1
        if campo_chave:
            _i, _n, off, length, _t, _d = campo_chave
            chaves.append(bytes(rec[off - 1:off - 1 + length]))
        if vistos >= amostra:
            break

    f_bcd = (bcd_ruins / bcd_tot) if bcd_tot else 0.0
    f_asc = (asc_ruins / asc_tot) if asc_tot else 0.0
    f_dup = (1 - len(set(chaves)) / len(chaves)) if len(chaves) > 1 else 0.0
    pad_ruins, pad_tot = ((0, 0) if pagina is None
                          else _padding_nao_zero(dat, reclen, header, pagina))
    f_pad = (pad_ruins / pad_tot) if pad_tot else 0.0
    return {
        "header": header,
        "pagina": pagina,
        "registros": vistos,
        "com_conteudo": com_conteudo,
        "soma": f_bcd + f_asc + f_dup + f_pad,
        "frac_bcd": f_bcd,
        "frac_ascii": f_asc,
        "frac_chave_dup": f_dup,
        "frac_padding": f_pad,
        "score": max(f_bcd, f_asc, f_dup, f_pad),
    }


# --------------------------------------------------------------- pagina, por tabela
def _paginas_viaveis(filesize: int, reclen: int) -> list[int | None]:
    """Tamanhos de pagina que podem descrever este arquivo (o registro tem de caber)."""
    return [p for p in PAGINAS_CANDIDATAS
            if p is None or (p // reclen) >= 1]


def _grade_equivalente(filesize: int, reclen: int, a: dict, b: dict,
                       limite: int = 256) -> bool:
    """True quando dois candidatos leem os registros dos MESMOS lugares.

    Acontece quando a pagina e multiplo exato do reclen (contiguo e paginado coincidem) ou
    quando os headers diferem por um multiplo da pagina. Nesse caso nao ha ambiguidade a
    reportar: sao duas descricoes da mesma leitura.
    """
    ga = offsets_candidato(filesize, reclen, a["header"], a["pagina"])
    gb = offsets_candidato(filesize, reclen, b["header"], b["pagina"])
    for _ in range(limite):
        oa, ob = next(ga, None), next(gb, None)
        if oa != ob:
            return False
        if oa is None:
            return True
    return True


def escolher_pagina(dat: bytes, reclen: int, campos, header: int,
                    tabela: str = "") -> dict:
    """Com o header fixo, descobre e PROVA o tamanho de pagina de uma tabela.

    Levanta LayoutIndeterminado quando nenhum candidato e plausivel ou quando o vencedor
    nao tem margem sobre um rival que le os registros de outro lugar.
    """
    filesize = len(dat)
    scores = [pontuar(dat, reclen, campos, header, p)
              for p in _paginas_viaveis(filesize, reclen)]
    if not any(s["registros"] for s in scores):
        raise TabelaVazia(
            f"{tabela}: nenhum registro preenchido (tamanho {filesize}, reclen {reclen}, "
            f"header {header}) — tabela vazia, nada a converter.")
    if not any(s["com_conteudo"] for s in scores):
        raise TabelaVazia(
            f"{tabela}: os registros nao carregam informacao — nenhum texto imprimivel e "
            f"nenhum numero diferente de zero, em nenhum layout candidato. Nao ha o que "
            f"decidir nem o que converter.")

    # Uma amostra de 1-3 registros nao sustenta conclusao sobre layout; se nenhum candidato
    # alcanca o minimo, decidimos com o que ha, mas o aviso de margem apertada cobre.
    grandes = [s for s in scores if s["registros"] >= MIN_REGISTROS]
    scores = grandes if grandes else [s for s in scores if s["registros"] > 0]

    # Ordena pelo pior sinal e, no empate exato, pela soma dos quatro — que usa toda a
    # informacao disponivel em vez de so a do sinal dominante.
    scores.sort(key=lambda s: (s["score"], s["soma"]))
    melhor = scores[0]

    # Backstop absoluto: so bcd/ascii. Chave duplicada fica fora porque e legitima em
    # tabela filha (ver docstring do modulo).
    pior_bcd_ascii = max(melhor["frac_bcd"], melhor["frac_ascii"])
    if pior_bcd_ascii > LIMITE_BCD_ASCII:
        raise LayoutIndeterminado(
            f"{tabela}: nao parece DataFlex legivel — o melhor candidato (pagina "
            f"{melhor['pagina']}) tem bcd {melhor['frac_bcd']:.2%} e ascii "
            f"{melhor['frac_ascii']:.2%}, acima do limite de {LIMITE_BCD_ASCII:.0%}. O "
            f"reclen pode nao estar em 0x9A nesta versao, ou o arquivo usa "
            f"compressao/Unicode. Nao convertido.")

    rivais = [s for s in scores[1:] if not _grade_equivalente(filesize, reclen, melhor, s)]
    if rivais:
        segundo = rivais[0]
        melhor["rival"] = segundo
        if melhor["score"] >= segundo["score"] and melhor["soma"] >= segundo["soma"]:
            # Empate exato nos quatro sinais. Acontece em tabela sem conteudo real — na
            # MercadoTina, `etiqueta` sao 8,9 MB em que so um byte contador varia, e nao ha
            # invariante para violar. Abortar a conversao por isso seria alarme falso caro,
            # e afirmar prova seria mentira. Escolhemos o layout do formato e dizemos que
            # esta tabela NAO foi provada — quem le o relatorio decide se confere.
            melhor = min(
                (s for s in scores
                 if s["score"] == melhor["score"] and s["soma"] == melhor["soma"]),
                key=lambda s: (s["pagina"] is None, s["pagina"] or 0))
            melhor["provado"] = False
            melhor["margem"] = 1.0
            # Duas mensagens, duas audiencias: `aviso` chega na caixa de dialogo de quem opera
            # a conversao e nao pode carregar percentual nenhum; `aviso_tecnico` sai no stdout
            # e serve para diagnostico.
            melhor["aviso"] = (
                f"{tabela}: layout nao confirmado — a tabela nao tem conteudo suficiente para "
                f"confirmar como os registros estao posicionados. Convertida com o layout "
                f"padrao do formato; confira uma amostra se esta tabela importar.")
            melhor["aviso_tecnico"] = (
                f"{tabela}: pagina {melhor['pagina']} e pagina {segundo['pagina']} pontuam "
                f"identico nos quatro sinais ({melhor['score']:.2%}) — nada a violar.")
            return melhor

        fator = (segundo["score"] / melhor["score"]) if melhor["score"] else float("inf")
        melhor["provado"] = True
        melhor["margem"] = fator
        if fator < FATOR_MARGEM_CONFORTAVEL:
            melhor["aviso"] = (
                f"{tabela}: o layout foi escolhido com pouca folga sobre a alternativa. "
                f"Confira uma amostra desta tabela a olho.")
            melhor["aviso_tecnico"] = (
                f"{tabela}: pagina {melhor['pagina']} ganhou de pagina {segundo['pagina']} "
                f"com {melhor['score']:.2%} contra {segundo['score']:.2%} (fator {fator:.2f}x).")
    else:
        # Um unico layout viavel (registro maior que qualquer pagina candidata): nao ha
        # ambiguidade a resolver, e o backstop acima ja garantiu que ele e legivel.
        melhor["provado"] = True
        melhor["margem"] = float("inf")
    return melhor


# --------------------------------------------------------------- header, por base
def _headers_candidatos(menor_arquivo: int) -> list[int]:
    """Headers a testar, na grade de 512B. O piso e o fim da tabela de descritores."""
    piso = GRADE_HEADER * ((DESC_OFF + 8) // GRADE_HEADER + 1)
    return [h for h in range(piso, 12 * GRADE_HEADER + 1, GRADE_HEADER)
            if h < menor_arquivo]


def descobrir_header(amostras: list[tuple[str, bytes, int, list]]) -> dict:
    """Descobre o header do FORMATO por consenso entre varias tabelas da base.

    `amostras`: [(tabela, dat, reclen, campos)]. Para cada header candidato, pontua cada
    tabela com o melhor tamanho de pagina disponivel e soma os scores. O header vencedor e
    o de menor score agregado — e, entre os que empatam (grade equivalente), o MAIOR, que e
    o que nao le metadados como se fossem dados.

    Levanta LayoutIndeterminado quando nenhum header explica a base.
    """
    if not amostras:
        raise LayoutIndeterminado("nenhuma tabela com dados para descobrir o header.")

    menor = min(len(d) for _t, d, _r, _c in amostras)
    resultados = []
    for header in _headers_candidatos(menor):
        total = 0.0
        por_tabela = {}
        viavel = True
        for tabela, dat, reclen, campos in amostras:
            cands = [pontuar(dat, reclen, campos, header, p)
                     for p in _paginas_viaveis(len(dat), reclen)]
            cands = [c for c in cands if c["registros"] >= MIN_REGISTROS]
            if not cands:
                viavel = False
                break
            melhor = min(cands, key=lambda s: s["score"])
            por_tabela[tabela] = melhor
            total += melhor["score"]
        if viavel:
            resultados.append({"header": header, "score": total / len(amostras),
                               "por_tabela": por_tabela})

    if not resultados:
        raise LayoutIndeterminado(
            "nenhum header candidato explica a base — nenhuma tabela da amostra produziu "
            f"registros suficientes ({MIN_REGISTROS}) em nenhum header testado. Versao de "
            "DataFlex nao coberta.")

    resultados.sort(key=lambda r: r["score"])
    escolhido = resultados[0]

    # Separacao relativa, como na pagina: exigimos que o vencedor ganhe com folga do
    # proximo header que leia de outro lugar. Medido na MercadoTina o consenso separa por
    # duas ordens de grandeza (3072 contra o 2o colocado), entao a folga aqui e barata.
    proximo = next((r for r in resultados[1:]
                    if r["header"] != escolhido["header"]), None)
    if proximo is None:
        raise LayoutIndeterminado(
            "so um header candidato produziu registros — sem segundo candidato nao ha "
            "com o que comparar, e nao afirmamos um layout sem prova.")
    fator = (proximo["score"] / escolhido["score"]) if escolhido["score"] else float("inf")
    escolhido["margem"] = fator
    escolhido["proximo"] = {"header": proximo["header"], "score": proximo["score"]}
    if fator < FATOR_MARGEM_CONFORTAVEL:
        raise LayoutIndeterminado(
            f"o header nao se decide: {escolhido['header']} deu {escolhido['score']:.2%} "
            f"de invalidos em media e {proximo['header']} deu {proximo['score']:.2%} "
            f"(fator {fator:.2f}x, exigimos {FATOR_MARGEM_CONFORTAVEL:.0f}x). O header e "
            f"constante do formato — sem consenso claro entre as tabelas nao ha base para "
            f"escolher. Nada foi convertido.")

    if escolhido["header"] != HEADER_OBSERVADO:
        escolhido["aviso"] = (
            f"header descoberto = {escolhido['header']}, diferente do unico valor conhecido "
            f"({HEADER_OBSERVADO}). O leitor foi validado so contra {HEADER_OBSERVADO}; "
            f"confira uma tabela a olho antes de confiar na carga.")
    escolhido["candidatos"] = sorted(
        ({"header": r["header"], "score": r["score"]} for r in resultados),
        key=lambda r: r["score"])
    return escolhido


# --------------------------------------------------------------- self-check
def _selfcheck():
    """Prova o modulo contra a base MercadoTina.

    Cobre as 4 tabelas paginadas que o bug de layout corrompia e 2 contiguas de controle.
    """
    import sys
    import df_reader

    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    base = (r"C:\Users\Mateus Borges\Downloads\Issues"
            r"\8631_MercadoTina_Conversao_Protheus\Origem Protheus")

    # (tabela, pagina esperada) — 4 paginadas do bug + 2 contiguas de controle
    casos = [("SECAO", 0x200), ("NCM", 0x200), ("PAISES", 0x200), ("FORMA", 0x200),
             ("PRODUTOS", None), ("CLIENTES", None)]

    carregadas = []
    for tabela, esperada in casos:
        datp = df_reader._find(os.path.join(base, "Data"), tabela, [".dat", ".DAT"])
        dat = open(datp, "rb").read()
        fd = df_reader._parse_fd(os.path.join(base, "DDSrc"), tabela)
        reclen, campos = df_reader.table_meta(dat, fd, len(dat), tabela)
        carregadas.append((tabela, dat, reclen, campos, esperada))

    falhas = []

    # ---- header por consenso
    amostras = [(t, d, r, c) for t, d, r, c, _e in carregadas]
    h = descobrir_header(amostras)
    print(f"header por consenso: {h['header']} (score medio {h['score']:.2%})")
    print("  candidatos:", ", ".join(f"{c['header']}={c['score']:.2%}"
                                     for c in h["candidatos"][:6]))
    if h["header"] != HEADER_OBSERVADO:
        falhas.append(f"header: consenso deu {h['header']}, esperado {HEADER_OBSERVADO}")
    print()

    # ---- pagina por tabela
    print(f"{'tabela':<10} {'reclen':>6} {'BCD':>7} {'ASCII':>7} {'dupPK':>7} "
          f"{'escolhida':>10} {'esperada':>9}")
    print("-" * 62)
    for tabela, dat, reclen, campos, esperada in carregadas:
        try:
            s = escolher_pagina(dat, reclen, campos, h["header"], tabela)
        except LayoutIndeterminado as e:
            falhas.append(f"{tabela}: {e}")
            print(f"{tabela:<10} {reclen:>6}  INDETERMINADO")
            continue
        ok = _grade_equivalente(
            len(dat), reclen, s,
            {"header": h["header"], "pagina": esperada})
        nome = "contiguo" if s["pagina"] is None else str(s["pagina"])
        esp = "contiguo" if esperada is None else str(esperada)
        print(f"{tabela:<10} {reclen:>6} {s['frac_bcd']:>6.2%} {s['frac_ascii']:>6.2%} "
              f"{s['frac_chave_dup']:>6.2%} {nome:>10} {esp:>9} {'' if ok else '  <-- ERRADO'}")
        if not ok:
            falhas.append(f"{tabela}: escolheu pagina {s['pagina']}, esperado {esperada}")

    print()
    if falhas:
        print("FALHAS:")
        for f in falhas:
            print("  -", f)
        raise SystemExit(1)
    print("OK — header por consenso = 3072 e a pagina certa nas 6 tabelas.")


if __name__ == "__main__":
    _selfcheck()
