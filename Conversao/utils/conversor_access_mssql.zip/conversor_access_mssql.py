# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "dlt[sql-database]>=1.19",
#     "pyarrow",
#     "pandas",
#     "pyodbc",
#     "sqlalchemy-access",
#     "adbc-driver-manager",
#     "pyyaml",
# ]
# ///
"""Conversor Oxente autocontido — MDB (Access) -> SQL Server (sem parquet intermediário materializado).

Roda via `uv run conversor_access_mssql.py ...` (uv provisiona Python + deps na 1a execucao).
Cada tabela de cada .mdb vira <mdb>_<tabela> (translit + lowercase) no schema dbo
do banco de destino. Disparado pela tab "Configuracao Access" do conversor Sol.NET.

  uv run conversor_access_mssql.py --mdb <arquivo.mdb|pasta> --server <host[,porta]> \
      --user <u> --senha <p> --db <banco> [--mdb-senha <p>] [--limit N]

Diagnostico: durante a run escreve 4 arquivos separados (telemetria estruturada,
progresso, log do dlt, erros) e ao final faz merge num unico conversor_<ts>.log com
frontmatter YAML no topo (entre ---) e o corpo seccionado abaixo. Ver abrir_logs/merge_final.
"""
import argparse
import glob
import importlib.metadata
import json
import locale
import logging
import os
import platform
import subprocess
import sys
import traceback
import unicodedata

import dlt
import pyarrow as pa
import pyarrow.compute as pc
import pyodbc
import sqlalchemy as sa
import yaml
from dlt.common.normalizers.naming.sql_ci_v1 import NamingConvention as _NamingBase
from dlt.sources.sql_database import sql_database

# a pasta do script no PYTHONPATH (herdado pelos subprocessos de normalizacao do dlt,
# que rodam via spawn no Windows) para que o dlt reimporte este modulo pelo nome
# (SCHEMA__NAMING) e carregue a NamingConvention. sys.path cobre o processo atual.
_BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _BASE)
os.environ["PYTHONPATH"] = _BASE + os.pathsep + os.environ.get("PYTHONPATH", "")
os.environ["SCHEMA__NAMING"] = "conversor_access_mssql"
# WARNING+ no dlt: o nivel INFO e ~99% maquinario por tabela (normalizer/parquet/jobs criados,
# "seen data for the first time"); sem valor diagnostico quando nao ha erro. Retry/falha saem em
# WARNING+ e sobrevivem. Corta a secao EVENTOS DLT de ~2400 linhas para um punhado.
os.environ.setdefault("RUNTIME__LOG_LEVEL", "WARNING")
# item bufferizado = RecordBatch (nao linha) no backend pyarrow; 4 batches ja mantem o pipe
# alimentado com retencao minima em RAM (concatena zero-copy para o row group). Aumentar so
# incharia memoria sem ganho reproduzivel -- medido: a variancia do extract engole o efeito.
os.environ["DATA_WRITER__BUFFER_MAX_ITEMS"] = "4"
# apaga o load package apos cada carga -> nao duplica o dado em disco (parquet intermediario).
os.environ["LOAD__DELETE_COMPLETED_JOBS"] = "true"

ACCESS_DRIVER = "Microsoft Access Driver (*.mdb, *.accdb)"


class NamingConvention(_NamingBase):
    # sql_ci (lowercase, case-insensitive, SQL-safe) + transliteracao de acentos via
    # NFKD (ç->c, ó->o): nomes previsiveis e ASCII no destino. Selecionada pelo env acima.
    def normalize_identifier(self, identifier: str) -> str:
        ascii_id = "".join(
            c for c in unicodedata.normalize("NFKD", identifier) if not unicodedata.combining(c)
        )
        return super().normalize_identifier(ascii_id)


def odbc_access(mdb_path: str, senha: str | None) -> str:
    s = "DRIVER={" + ACCESS_DRIVER + "};DBQ=" + mdb_path + ";"
    return s + ("PWD=" + senha + ";" if senha else "")


def engine_access(mdb_path: str, user: str | None, senha: str | None):
    # senha em dois lugares: odbc_connect (pyodbc nas queries) e url.password
    # (sqlalchemy-access reflete PK/FK via DAO/COM, que le url.password).
    url = sa.engine.URL.create(
        "access+pyodbc",
        username=user or ("admin" if senha else None),
        password=senha or None,
        query={"odbc_connect": odbc_access(mdb_path, senha)},
    )
    return sa.create_engine(url, poolclass=sa.pool.NullPool)


def creds_mssql(server: str, user: str, senha: str, db: str) -> dict:
    host, _, porta = server.partition(",")
    return {
        "drivername": "mssql",
        "host": host,
        "port": int(porta) if porta else 1433,
        "database": db,
        "username": user,
        "password": senha,
        "query": {"driver": "ODBC Driver 17 for SQL Server", "TrustServerCertificate": "yes"},
    }


def sanitizar_floats(tab: pa.Table) -> pa.Table:
    # NaN/Inf em colunas float viram NULL: o MSSQL FLOAT nao aceita os especiais IEEE.
    for i, campo in enumerate(tab.schema):
        if pa.types.is_floating(campo.type):
            col = tab.column(i)
            tab = tab.set_column(i, campo.name, pc.if_else(pc.is_finite(col), col, pa.scalar(None, campo.type)))
    return tab


# ----------------------------------------------------------------------------- telemetria (A)
def _ver(dist: str) -> str | None:
    try:
        return importlib.metadata.version(dist)
    except Exception:
        return None


def _uv_version() -> str | None:
    try:
        import subprocess

        r = subprocess.run(["uv", "--version"], capture_output=True, text=True, timeout=5)
        return r.stdout.strip() or None
    except Exception:
        return None


def _ram_mb() -> int | None:
    # RAM fisica total via Win32 GlobalMemoryStatusEx; best-effort (None fora do Windows).
    try:
        import ctypes

        class _MS(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        m = _MS()
        m.dwLength = ctypes.sizeof(_MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return m.ullTotalPhys // (1024 * 1024)
    except Exception:
        return None


def _odbc_sistema(bits: int) -> dict:
    # drivers ODBC registrados no Windows no hive do bitness pedido (64 ou 32), lidos
    # explicitamente via KEY_WOW64_*KEY mesmo que o Python seja do outro bitness. {nome: dll}.
    # O caminho da DLL confirma o bitness real (system32 x SysWOW64 / ProgramFiles x ...x86).
    try:
        import winreg
    except Exception:
        return {}
    flag = winreg.KEY_WOW64_64KEY if bits == 64 else winreg.KEY_WOW64_32KEY
    out: dict = {}
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\ODBC\ODBCINST.INI\ODBC Drivers",
                            0, winreg.KEY_READ | flag) as k:
            i = 0
            while True:
                try:
                    nome, val, _ = winreg.EnumValue(k, i)
                    i += 1
                except OSError:
                    break
                if val != "Installed":
                    continue
                dll = None
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\ODBC\ODBCINST.INI\{nome}",
                                        0, winreg.KEY_READ | flag) as dk:
                        dll = winreg.QueryValueEx(dk, "Driver")[0]
                except OSError:
                    pass
                out[nome] = dll
    except OSError:
        pass
    return out


def _bitness_lib(caminho: str | None) -> str | None:
    # bitness pelo sufixo da lib nativa compilada (.pyd/.dll) do Python.
    if not caminho:
        return None
    n = caminho.lower()
    if "amd64" in n or "x86_64" in n:
        return "64bit"
    if "win32" in n or "i686" in n:
        return "32bit"
    return None


def coletar_odbc() -> dict:
    # No Windows, DRIVERS ODBC vivem so a nivel de sistema: HKLM\SOFTWARE\ODBC\ODBCINST.INI
    # (hives 64 e 32). Nao ha camada env nem user para drivers -- HKCU\...\ODBC.INI guarda
    # data sources (DSN), nao drivers. Por isso, ao contrario do ADBC (busca_env/usuario/
    # sistema), o ODBC tem so busca_sistema_*. runtime_python = o que o pyodbc do processo
    # enxerga (so o bitness do Python; Access ACE so em x64 com Python x86 e a falha classica).
    runtime: list[str] = []
    try:
        runtime = sorted(pyodbc.drivers())
    except Exception:
        pass
    return {
        "runtime_python": runtime,
        "busca_sistema_64bit": _odbc_sistema(64),
        "busca_sistema_32bit": _odbc_sistema(32),
    }


def _adbc_registro(root, bits: int) -> dict:
    # drivers ADBC registrados no Windows em SOFTWARE\ADBC\Drivers\<nome> (HKLM=sistema,
    # HKCU=usuario), lidos no hive do bitness pedido. Cada driver: driver/version/entrypoint/source.
    try:
        import winreg
    except Exception:
        return {}
    flag = winreg.KEY_WOW64_64KEY if bits == 64 else winreg.KEY_WOW64_32KEY
    out: dict = {}
    try:
        with winreg.OpenKey(root, r"SOFTWARE\ADBC\Drivers", 0, winreg.KEY_READ | flag) as k:
            i = 0
            while True:
                try:
                    sub = winreg.EnumKey(k, i)
                    i += 1
                except OSError:
                    break
                campos: dict = {}
                try:
                    with winreg.OpenKey(root, rf"SOFTWARE\ADBC\Drivers\{sub}", 0,
                                        winreg.KEY_READ | flag) as dk:
                        for campo in ("driver", "version", "entrypoint", "source"):
                            try:
                                campos[campo] = winreg.QueryValueEx(dk, campo)[0]
                            except OSError:
                                pass
                except OSError:
                    pass
                out[sub] = campos
    except OSError:
        pass
    return out


def _adbc_manifests(diretorios: list[str]) -> dict:
    # manifests .toml de driver ADBC nos diretorios dados; extrai version + shared lib da
    # plataforma atual ([Driver.shared].<so>_<arch>) + entrypoint.
    import tomllib

    so = {"windows": "windows", "linux": "linux", "darwin": "osx"}.get(
        platform.system().lower(), platform.system().lower())
    maq = platform.machine().lower()
    arch = "amd64" if maq in ("amd64", "x86_64") else ("x86" if maq in ("i386", "i686", "x86") else maq)
    plat = f"{so}_{arch}"
    out: dict = {}
    for d in diretorios:
        d = os.path.expandvars(d)
        try:
            arquivos = os.listdir(d)
        except OSError:
            continue
        for f in arquivos:
            if not f.lower().endswith(".toml"):
                continue
            caminho = os.path.join(d, f)
            entrada = {"manifesto": caminho}
            try:
                with open(caminho, "rb") as fp:
                    doc = tomllib.load(fp)
                drv = doc.get("Driver", {}) or {}
                entrada.update(version=doc.get("version"),
                               driver=(drv.get("shared", {}) or {}).get(plat),
                               entrypoint=drv.get("entrypoint"))
            except Exception:
                pass
            out[os.path.splitext(f)[0]] = entrada
    return out


def _adbc_ambiente_python() -> dict:
    # drivers ADBC trazidos por pacote Python (adbc-driver-*), com versao + lib nativa + bitness.
    out: dict = {}
    try:
        from importlib.metadata import distributions

        for d in distributions():
            nome = d.metadata["Name"] or ""
            if not nome.startswith("adbc-driver-") or nome == "adbc-driver-manager":
                continue
            lib = None
            try:
                for f in (d.files or []):
                    s = str(f)
                    if s.endswith((".dll", ".so", ".pyd")) and "driver" in s.lower():
                        lib = str(d.locate_file(f))
                        break
            except Exception:
                pass
            out[nome] = {"versao": d.version, "lib_nativa": lib, "bitness": _bitness_lib(lib)}
    except Exception:
        pass
    return out


def coletar_adbc() -> dict:
    # superficie de descoberta do ADBC na ordem de precedencia (default = todos os flags
    # ligados): SEARCH_ENV (ADBC_DRIVER_PATH + VIRTUAL_ENV/CONDA_PREFIX \etc\adbc\drivers),
    # SEARCH_USER (HKCU + %LOCALAPPDATA%\ADBC\Drivers), SEARCH_SYSTEM (HKLM, hives 64/32).
    # ambiente_python = drivers trazidos por pacote adbc-driver-* (fora da superficie de manifest).
    out: dict = {"driver_manager": None}
    try:
        import adbc_driver_manager as a

        lib = getattr(getattr(a, "_lib", None), "__file__", None)
        out["driver_manager"] = {"versao": getattr(a, "__version__", None),
                                 "lib_nativa": lib, "bitness": _bitness_lib(lib)}
    except Exception:
        pass

    env_dirs: list[str] = []
    if os.environ.get("ADBC_DRIVER_PATH"):
        env_dirs += os.environ["ADBC_DRIVER_PATH"].split(os.pathsep)
    for var in ("VIRTUAL_ENV", "CONDA_PREFIX"):
        base = os.environ.get(var)
        if base:
            env_dirs.append(os.path.join(base, "etc", "adbc", "drivers"))
    out["busca_env"] = _adbc_manifests(env_dirs)

    try:
        import winreg
        hklm, hkcu = winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER
    except Exception:
        hklm = hkcu = None
    if hkcu is not None:
        usuario = _adbc_registro(hkcu, 64)
        usuario.update(_adbc_registro(hkcu, 32))
        lad = os.environ.get("LOCALAPPDATA")
        if lad:
            usuario.update(_adbc_manifests([os.path.join(lad, "ADBC", "Drivers")]))
        out["busca_usuario"] = usuario
    if hklm is not None:
        out["busca_sistema_64bit"] = _adbc_registro(hklm, 64)
        out["busca_sistema_32bit"] = _adbc_registro(hklm, 32)

    out["ambiente_python"] = _adbc_ambiente_python()
    return out


def coletar_drivers() -> dict:
    return {"odbc": coletar_odbc(), "adbc": coletar_adbc()}


def coletar_ambiente(args) -> dict:
    return {
        "python": sys.version.split()[0],
        "python_bits": platform.architecture()[0],
        "python_exe": sys.executable,
        "plataforma": platform.platform(),
        "cpus": os.cpu_count(),
        "ram_mb": _ram_mb(),
        "encoding": locale.getpreferredencoding(False),
        "uv": _uv_version(),
        "venv": sys.prefix,
        "deps": {d: _ver(d) for d in (
            "dlt", "pyarrow", "pyodbc", "sqlalchemy", "sqlalchemy-access", "adbc-driver-manager")},
        "drivers": coletar_drivers(),
        "envs": {k: os.environ.get(k) for k in ("SCHEMA__NAMING", "RUNTIME__LOG_LEVEL")},
        "args": {"server": args.server, "db": args.db, "mdb": args.mdb, "limit": args.limit},
    }


def _odbc_mssql(dest: dict) -> str:
    return (
        f"DRIVER={{{dest['query']['driver']}}};SERVER={dest['host']},{dest['port']};"
        f"DATABASE={dest['database']};UID={dest['username']};PWD={dest['password']};"
        "TrustServerCertificate=yes;"
    )


def coletar_destino_sql(dest: dict) -> dict:
    # versao/edicao/bitness e collation do destino: o que discrimina uma instancia da outra
    # (o erro 8631 passa numa e estoura noutra). CAST AS NVARCHAR porque SERVERPROPERTY
    # devolve sql_variant, que o pyodbc nao decodifica ("ODBC SQL type -16 is not supported").
    dados: dict = {}
    try:
        cn = pyodbc.connect(_odbc_mssql(dest), timeout=10)
        cur = cn.cursor()
        cur.execute("SELECT @@VERSION")
        dados["version"] = cur.fetchone()[0]
        cur.execute(
            "SELECT CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('ProductLevel') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('EngineEdition') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('Collation') AS NVARCHAR(128))"
        )
        pv, pl, ed, ee, col = cur.fetchone()
        dados.update(product_version=pv, product_level=pl, edition=ed,
                     engine_edition=ee, server_collation=col)
        cur.execute(
            "SELECT CAST(collation_name AS NVARCHAR(128)), compatibility_level"
            " FROM sys.databases WHERE name = ?", dest["database"])
        r = cur.fetchone()
        if r:
            dados["db_collation"], dados["db_compatibility_level"] = r[0], r[1]
        dados["odbc_driver"] = cn.getinfo(pyodbc.SQL_DRIVER_NAME)
        dados["odbc_driver_version"] = cn.getinfo(pyodbc.SQL_DRIVER_VER)
        cn.close()
    except Exception as e:
        dados["erro"] = str(e)[:200]
    return dados


# drivers necessarios (no bitness do Python = x64). access/odbc_sqlserver sao bloqueio
# absoluto (sem eles nao le a origem / nao conecta o destino); adbc_mssql evita o caminho
# insert_values (degradacao ~10-70x + erro 8631 no parser) -- com ele o dlt usa parquet/bulk
# automaticamente. Instalacao: ODBC/ACE via `winget install` (machine-scope, pode pedir UAC se
# o processo nao estiver elevado); ADBC via `dbc` (per-user).
REQUISITOS_DRIVERS = [
    {"chave": "access", "nome": "Microsoft Access Driver (*.mdb, *.accdb)",
     "amigavel": "Leitura dos bancos de origem (.mdb)",
     "winget": "Microsoft.AccessDatabaseEngine.2016"},
    {"chave": "odbc_sqlserver", "nome": "ODBC Driver NN for SQL Server",
     "amigavel": "Conexão com o banco de destino (SQL Server)",
     "winget": "Microsoft.msodbcsql.18"},
    {"chave": "adbc_mssql", "nome": "ADBC mssql (Columnar)",
     "amigavel": "Carga rápida no banco de destino",
     "dbc": "mssql"},
]


def _exec(cmd: list[str], timeout: int) -> dict:
    # roda um subprocesso e devolve o registro para o log: comando, returncode e o rabo da saida.
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {"comando": " ".join(cmd), "returncode": r.returncode,
                "saida": (r.stdout or r.stderr or "").strip()[-200:]}
    except Exception as e:
        return {"comando": " ".join(cmd), "erro": str(e)[:120]}


def _winget_instalado(wid: str) -> tuple[bool, dict]:
    # `winget list --exact --id <id>` -> instalado se sai 0 e o id aparece na saida (sai != 0
    # quando nada casa). Devolve (instalado, registro p/ log).
    reg = _exec(["winget", "list", "--exact", "--id", wid, "--accept-source-agreements"], 120)
    instalado = reg.get("returncode") == 0 and wid.lower() in (reg.get("saida") or "").lower()
    return instalado, reg


def _dbc_instalado(alvo: str) -> tuple[bool, dict]:
    # `dbc list` -> instalado se o alvo (ex.: mssql) aparece na lista de drivers ADBC.
    reg = _exec(["uv", "tool", "run", "dbc", "list"], 120)
    instalado = reg.get("returncode") == 0 and alvo.lower() in (reg.get("saida") or "").lower()
    return instalado, reg


def _detectar(req: dict) -> tuple[bool, dict]:
    # UNICA logica de deteccao: a mesma ferramenta que instala. winget (access/odbc) -> winget list;
    # dbc (adbc) -> dbc list. NAO consulta pyodbc/registro -- garante a versao gerida pelo conversor.
    if req.get("winget"):
        ja, reg = _winget_instalado(req["winget"])
        return ja, {"metodo": "winget", "id": req["winget"], "verificacao": reg}
    if req.get("dbc"):
        ja, reg = _dbc_instalado(req["dbc"])
        return ja, {"metodo": "dbc", "alvo": req["dbc"], "verificacao": reg}
    return False, {"metodo": None}


def _obter_driver(req: dict) -> dict:
    # instala o driver (a deteccao ja rodou em _detectar). winget install (ODBC/ACE, machine-scope
    # -> pode pedir UAC) ou dbc install (ADBC, per-user). Devolve o registro da instalacao.
    if req.get("dbc"):
        reg = _exec(["uv", "tool", "run", "dbc", "install", req["dbc"]], 300)
    elif req.get("winget"):
        reg = _exec(
            ["winget", "install", "--exact", "--id", req["winget"], "--accept-package-agreements",
             "--accept-source-agreements", "--silent", "--disable-interactivity"], 600)
    else:
        return {"instalado": False, "resultado": "sem_metodo"}
    ok = reg.get("returncode") == 0
    return {"instalado": ok, "resultado": "instalado" if ok else "falha", "instalacao": reg}


def preflight_drivers(progresso) -> dict:
    # hard constraint: deteccao EXCLUSIVA via winget list / dbc list; instala os ausentes (winget
    # install / dbc install). Emite progresso EM TEMPO REAL (verificando / instalando / resultado)
    # para o analista acompanhar -- winget install pode demorar. `acoes` registra por driver a
    # deteccao + (ja_instalado | instalado | falha). Os faltantes bloqueiam a conversao.
    out: dict = {"presentes": [], "faltantes": [], "acoes": []}
    for req in REQUISITOS_DRIVERS:
        amigavel = req["amigavel"]
        progresso(f"  Verificando {amigavel}...")
        presente, deteccao = _detectar(req)
        if presente:
            progresso(f"  {amigavel}: ja instalado")
            out["presentes"].append(req["nome"])
            out["acoes"].append({"driver": req["nome"], "amigavel": amigavel,
                                 "resultado": "ja_instalado", **deteccao})
            continue
        progresso(f"  Instalando {amigavel}...")
        inst = _obter_driver(req)
        out["acoes"].append({"driver": req["nome"], "amigavel": amigavel,
                             "deteccao": deteccao, **inst})
        if inst["instalado"]:
            progresso(f"  {amigavel}: instalado com sucesso")
            out["presentes"].append(f"{req['nome']} (instalado agora)")
        else:
            progresso(f"  {amigavel}: FALHA ao instalar")
            out["faltantes"].append({"nome": req["nome"], "amigavel": amigavel,
                                     "acao": inst["resultado"]})
    return out


def _alertar_analista(faltantes: list) -> None:
    # caixa nativa do Windows quando algum driver nao pode ser instalado -- o conversor roda
    # disparado pela GUI (sessao do analista), entao a janela aparece mesmo sem console.
    try:
        import ctypes

        itens = "\n".join(f"- {f['amigavel']}" for f in faltantes)
        msg = f"Não foi possível instalar os drivers da conversão:\n\n{itens}\n\nInstale-os e reabra a conversão."
        # MB_OK | MB_ICONWARNING (0x30) | MB_TOPMOST (0x40000)
        ctypes.windll.user32.MessageBoxW(0, msg, "Sol.NET - Conversão Access", 0x30 | 0x40000)
    except Exception:
        pass


def metricas_carga(pipe) -> dict:
    # tempos por etapa do trace do dlt; best-effort (isolado para nao derrubar o
    # resultado se a API do trace variar).
    out: dict = {}
    try:
        out["tempos_s"] = {
            s.step: round((s.finished_at - s.started_at).total_seconds(), 2)
            for s in pipe.last_trace.steps if s.started_at and s.finished_at
        }
    except Exception:
        pass
    return out


def carregar(engine, nome: str, dest: dict, limit: int | None, f_dlt) -> object:
    # chunk_size grande: o gargalo e o extract (leitura do Access). Default do dlt e 1000
    # linhas/batch -> muitos round-trips pyodbc/Jet; 50k corta a maioria das tabelas em 1-2 batches.
    reflexao = os.environ.get("CONV_REFLECTION", "full_with_precision")
    src = sql_database(credentials=engine, reflection_level=reflexao, backend="pyarrow")
    if limit:
        src.add_limit(limit)
    for tab, res in src.resources.items():  # prefixa o destino: <mdb>_<tabela>
        # replace: cada run substitui a tabela no destino -> conversao idempotente. O default
        # do dlt e append, que DUPLICARIA os dados a cada reexecucao no mesmo banco de destino.
        res.apply_hints(table_name=f"{nome}_{tab}", write_disposition="replace")
        res.add_map(sanitizar_floats)
    pipe = dlt.pipeline(
        pipeline_name=f"conv_{nome}",
        destination=dlt.destinations.mssql(credentials=dest),
        dataset_name="dbo",
        pipelines_dir=os.path.join(_BASE, "_dlt_state"),  # cache efemero; evita reusar schema antigo
    )
    info = pipe.run(src)
    print(info, file=f_dlt, flush=True)  # resumo tecnico da carga preservado no _dlt.log
    return pipe


# ----------------------------------------------------------------------------- logging / merge
def emit(f_meta, tipo: str, dados=None, mdb: str | None = None) -> None:
    # um evento JSON por linha (JSONL append-only): resiliente a crash, consolidado no merge.
    rec: dict = {"tipo": tipo}
    if mdb is not None:
        rec["mdb"] = mdb
    if dados is not None:
        rec["dados"] = dados
    f_meta.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
    f_meta.flush()


def abrir_logs(base: str):
    # 4 fluxos separados na origem (classificar e mais confiavel que remontar por regex),
    # todos com o mesmo timestamp da run (nao sobrescreve execucoes anteriores):
    #   _meta_<ts>.jsonl     telemetria estruturada -> frontmatter
    #   _progresso_<ts>.log  progresso humano (stdout)
    #   _dlt_<ts>.log        logging do dlt (sem o noise de polling)
    #   _erros_<ts>.log      tracebacks Python (stderr explicito)
    # merge final -> conversor_<ts>.log. NAO usa os.dup2: redirecionar os file descriptors do
    # SO conflita com o driver ODBC do Access (nativo) e derruba o processo (OSError 9 'bad fd').
    from datetime import datetime

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    paths = {
        "meta": os.path.join(base, f"_meta_{ts}.jsonl"),
        "progresso": os.path.join(base, f"_progresso_{ts}.log"),
        "dlt": os.path.join(base, f"_dlt_{ts}.log"),
        "erros": os.path.join(base, f"_erros_{ts}.log"),
        "final": os.path.join(base, f"conversor_{ts}.log"),
    }
    orig = (sys.stdout, sys.stderr)
    f_meta = open(paths["meta"], "w", encoding="utf-8", errors="replace", buffering=1)
    f_prog = open(paths["progresso"], "w", encoding="utf-8", errors="replace", buffering=1)
    f_dlt = open(paths["dlt"], "w", encoding="utf-8", errors="replace", buffering=1)
    f_err = open(paths["erros"], "w", encoding="utf-8", errors="replace", buffering=1)
    sys.stdout = f_prog  # progresso humano
    sys.stderr = f_dlt   # o StreamHandler do dlt captura sys.stderr na 1a carga -> _dlt.log
    # libs de terceiros (sqlalchemy etc.) tambem para o _dlt.log em WARNING+; o logger "dlt"
    # tem propagate=False (handler proprio, nivel via RUNTIME__LOG_LEVEL), entao nao duplica.
    logging.basicConfig(level=logging.WARNING, stream=f_dlt, force=True,
                        format="%(asctime)s|[%(levelname)s]|%(name)s|%(message)s")
    return orig, paths, (f_meta, f_prog, f_dlt, f_err)


def consolidar_meta(meta_path: str) -> dict:
    manifesto: dict = {"ambiente": None, "destino_sql": None, "drivers_preflight": None, "mdbs": {}}
    try:
        with open(meta_path, encoding="utf-8") as f:
            for linha in f:
                linha = linha.strip()
                if not linha:
                    continue
                try:
                    ev = json.loads(linha)
                except Exception:
                    continue
                tipo = ev.get("tipo")
                if tipo == "ambiente":
                    manifesto["ambiente"] = ev.get("dados")
                elif tipo == "destino_sql":
                    manifesto["destino_sql"] = ev.get("dados")
                elif tipo == "drivers_preflight":
                    manifesto["drivers_preflight"] = ev.get("dados")
                elif tipo == "resultado":
                    manifesto["mdbs"].setdefault(ev.get("mdb"), {})["resultado"] = ev.get("dados")
    except FileNotFoundError:
        pass
    manifesto["mdbs"] = [{"arquivo": k, **v} for k, v in manifesto["mdbs"].items()]
    return manifesto


SECOES_CORPO = (("PROGRESSO", "progresso"), ("EVENTOS DLT", "dlt"), ("ERROS", "erros"))


def _montar_corpo(paths: dict) -> tuple[str, dict]:
    # corpo seccionado + ranges (1-based, relativos ao inicio do corpo) de cada secao:
    # inicio = linha do header "===== X ====="; fim = ultima linha de conteudo (= o header se a
    # secao estiver vazia). A linha em branco separadora entre secoes nao entra no range.
    linhas: list[str] = []
    rel: dict = {}
    for titulo, chave in SECOES_CORPO:
        inicio = len(linhas) + 1
        linhas.append(f"===== {titulo} =====")
        try:
            with open(paths[chave], encoding="utf-8", errors="replace") as fp:
                conteudo = fp.read()
        except FileNotFoundError:
            conteudo = ""
        linhas.extend(conteudo.splitlines())
        rel[titulo] = {"inicio": inicio, "fim": len(linhas)}
        linhas.append("")  # separador em branco
    return "\n".join(linhas) + "\n", rel


def merge_final(paths: dict) -> None:
    # conversor_<ts>.log: frontmatter YAML (entre ---) + corpo seccionado. O frontmatter abre com
    # `secoes` = indice de linhas (inicio/fim) de cada secao do corpo. Inserir o indice muda o
    # tamanho do frontmatter (logo as linhas do corpo), entao serializa-se 1o com os campos vazios
    # (fixa a contagem de linhas), mede-se o offset e preenche-se os numeros reais -- trocar
    # placeholder por inteiro nao altera a quantidade de linhas, entao o offset continua valido.
    manifesto = consolidar_meta(paths["meta"])
    corpo, rel = _montar_corpo(paths)
    manifesto = {"secoes": {t: {"inicio": None, "fim": None} for t, _ in SECOES_CORPO}, **manifesto}

    def dump() -> str:
        return yaml.safe_dump(manifesto, default_flow_style=False, allow_unicode=True, sort_keys=False)

    offset = dump().count("\n") + 3  # linhas antes do corpo: "---", frontmatter, "---", branco
    manifesto["secoes"] = {t: {"inicio": rel[t]["inicio"] + offset, "fim": rel[t]["fim"] + offset}
                           for t, _ in SECOES_CORPO}
    with open(paths["final"], "w", encoding="utf-8", errors="replace") as out:
        out.write("---\n")
        out.write(dump())
        out.write("---\n\n")
        out.write(corpo)
    for chave in ("meta", "progresso", "dlt", "erros"):
        try:
            os.remove(paths[chave])
        except OSError:
            pass


def testar_conexao_mdb(mdb_path: str, senha: str | None) -> str | None:
    # Conexao leve para validar acesso antes de converter; devolve None se OK
    # ou uma descricao curta da falha. SQLSTATE 42000 do driver Access = senha
    # incorreta (a mensagem do driver e localizada, entao classificamos pelo
    # SQLSTATE, nao pelo texto).
    try:
        pyodbc.connect(odbc_access(mdb_path, senha), timeout=5).close()
        return None
    except pyodbc.Error as e:
        if e.args and e.args[0] == "42000":
            return "senha de origem incorreta"
        return (e.args[1] if len(e.args) > 1 else str(e))[:80]


def main():
    ap = argparse.ArgumentParser(description="Converte .mdb (Access) -> SQL Server")
    ap.add_argument("--mdb", required=True, help="arquivo .mdb ou pasta com .mdb")
    ap.add_argument("--server", required=True, help="host ou host,porta do SQL Server")
    ap.add_argument("--user", required=True)
    ap.add_argument("--senha", required=True)
    ap.add_argument("--db", required=True, help="banco de destino (deve existir)")
    ap.add_argument("--mdb-user", default=None, help="usuário dos .mdb protegidos (Access: admin)")
    ap.add_argument("--mdb-senha", default=None, help="senha dos .mdb protegidos")
    ap.add_argument("--limit", type=int, default=None, help="limite de linhas por tabela (smoke)")
    args = ap.parse_args()

    orig, paths, (f_meta, f_prog, f_dlt, f_err) = abrir_logs(_BASE)
    console = orig[0]

    def progresso(msg: str):
        console.write(msg + "\n")
        console.flush()
        print(msg, flush=True)  # tambem no _progresso.log

    try:
        amb = coletar_ambiente(args)
        emit(f_meta, "ambiente", dados=amb)
        dest = creds_mssql(args.server, args.user, args.senha, args.db)
        emit(f_meta, "destino_sql", dados=coletar_destino_sql(dest))

        # hard constraint: deteccao via winget/dbc + instala os ausentes; bloqueia se faltar.
        progresso("Verificando drivers necessarios...")
        pf = preflight_drivers(progresso)
        emit(f_meta, "drivers_preflight", dados=pf)
        if pf["faltantes"]:
            progresso("Drivers necessarios nao instalados - conversao bloqueada:")
            for d in pf["faltantes"]:
                progresso(f"  FALTA  {d['amigavel']} -> {d['acao']}")
            _alertar_analista(pf["faltantes"])
            return

        alvos = (
            [args.mdb]
            if args.mdb.lower().endswith(".mdb")
            else sorted(glob.glob(os.path.join(args.mdb, "**", "*.mdb"), recursive=True))
        )
        if not alvos:
            progresso(f"Nenhum arquivo .mdb encontrado em: {args.mdb}")
            return

        progresso("Conversao Access -> SQL Server")
        progresso(f"Destino: banco '{args.db}' em {args.server}")
        progresso(f"Log detalhado: {paths['final']}")

        # Preflight: testa a conexao com cada .mdb antes de converter. Os que falham
        # (senha de origem incorreta etc.) sao listados e pulados; converte so os acessiveis.
        progresso(f"Verificando conexao com {len(alvos)} banco(s) de origem...")
        conectados = []
        for m in alvos:
            erro = testar_conexao_mdb(m, args.mdb_senha)
            if erro is None:
                conectados.append(m)
                progresso(f"  OK     {os.path.basename(m)}")
            else:
                progresso(f"  FALHA  {os.path.basename(m)} - {erro}")

        progresso(f"Convertendo {len(conectados)} de {len(alvos)} banco(s).")
        if not conectados:
            progresso("Nenhum banco de origem acessivel. Verifique usuario/senha de origem.")
            return

        ok = 0
        for i, m in enumerate(conectados, 1):
            nome_mdb = os.path.basename(m)
            nome = os.path.splitext(nome_mdb)[0].lower()
            progresso(f"[{i}/{len(conectados)}] {nome_mdb}: convertendo...")
            engine = engine_access(m, args.mdb_user, args.mdb_senha)
            try:
                pipe = carregar(engine, nome, dest, args.limit, f_dlt)
                emit(f_meta, "resultado", dados={"status": "ok", **metricas_carga(pipe)}, mdb=nome_mdb)
                progresso(f"[{i}/{len(conectados)}] {nome_mdb}: concluido")
                ok += 1
            except Exception as e:
                traceback.print_exc(file=f_err)  # traceback completo -> _erros.log
                emit(f_meta, "resultado",
                     dados={"status": "falha", "erro": f"{type(e).__name__}: {e}"[:500]}, mdb=nome_mdb)
                progresso(f"[{i}/{len(conectados)}] {nome_mdb}: FALHOU ({type(e).__name__}) - veja o log")

        pulados = len(alvos) - len(conectados)
        final = f"Finalizado: {ok}/{len(conectados)} convertido(s)"
        progresso(final + (f", {pulados} pulado(s) por falha de conexao." if pulados else "."))
        if ok < len(conectados):
            progresso(f"Houve falhas na conversao. Detalhes em: {paths['final']}")
    finally:
        sys.stdout, sys.stderr = orig
        for f in (f_meta, f_prog, f_dlt, f_err):
            try:
                f.flush()
                f.close()
            except Exception:
                pass
        merge_final(paths)


if __name__ == "__main__":
    main()
