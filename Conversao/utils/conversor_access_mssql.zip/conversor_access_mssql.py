# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "dlt[sql-database]>=1.19",
#     "pyarrow",
#     "pyodbc",
#     "sqlalchemy-access",
#     "adbc-driver-manager",
# ]
# ///
"""Conversor Oxente autocontido — MDB (Access) -> SQL Server, direto (sem parquet).

Roda via `uv run conversor_access_mssql.py ...` (uv provisiona Python + deps na 1a execucao).
Cada tabela de cada .mdb vira <mdb>_<tabela> (translit + lowercase) no schema dbo
do banco de destino. Disparado pela tab "Configuracao Access" do conversor Sol.NET.

  uv run conversor_access_mssql.py --mdb <arquivo.mdb|pasta> --server <host[,porta]> \
      --user <u> --senha <p> --db <banco> [--mdb-senha <p>] [--limit N]
"""
import argparse
import glob
import logging
import os
import sys
import traceback
import unicodedata

import dlt
import pyarrow as pa
import pyarrow.compute as pc
import pyodbc
import sqlalchemy as sa
from dlt.common.normalizers.naming.sql_ci_v1 import NamingConvention as _NamingBase
from dlt.sources.sql_database import sql_database

# a pasta do script no PYTHONPATH (herdado pelos subprocessos de normalizacao do dlt,
# que rodam via spawn no Windows) para que o dlt reimporte este modulo pelo nome
# (SCHEMA__NAMING) e carregue a NamingConvention. sys.path cobre o processo atual.
_BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _BASE)
os.environ["PYTHONPATH"] = _BASE + os.pathsep + os.environ.get("PYTHONPATH", "")
os.environ["SCHEMA__NAMING"] = "conversor_access_mssql"
os.environ.setdefault("RUNTIME__LOG_LEVEL", "INFO")

ACCESS_DRIVER = "Microsoft Access Driver (*.mdb, *.accdb)"


class NamingConvention(_NamingBase):
    # sql_ci (lowercase, case-insensitive, SQL-safe) + transliteracao de acentos via
    # NFKD (ç->c, ó->o): nomes previsiveis e ASCII no destino. Selecionada pelo env acima.
    def normalize_identifier(self, identifier: str) -> str:
        ascii_id = "".join(
            c for c in unicodedata.normalize("NFKD", identifier) if not unicodedata.combining(c)
        )
        return super().normalize_identifier(ascii_id)


def odbc_access(mdb_path: str, senha: str | None) -> str:
    s = "DRIVER={" + ACCESS_DRIVER + "};DBQ=" + mdb_path + ";"
    return s + ("PWD=" + senha + ";" if senha else "")


def engine_access(mdb_path: str, user: str | None, senha: str | None):
    # senha em dois lugares: odbc_connect (pyodbc nas queries) e url.password
    # (sqlalchemy-access reflete PK/FK via DAO/COM, que le url.password).
    url = sa.engine.URL.create(
        "access+pyodbc",
        username=user or ("admin" if senha else None),
        password=senha or None,
        query={"odbc_connect": odbc_access(mdb_path, senha)},
    )
    return sa.create_engine(url, poolclass=sa.pool.NullPool)


def creds_mssql(server: str, user: str, senha: str, db: str) -> dict:
    host, _, porta = server.partition(",")
    return {
        "drivername": "mssql",
        "host": host,
        "port": int(porta) if porta else 1433,
        "database": db,
        "username": user,
        "password": senha,
        "query": {"driver": "ODBC Driver 17 for SQL Server", "TrustServerCertificate": "yes"},
    }


def sanitizar_floats(tab: pa.Table) -> pa.Table:
    # NaN/Inf em colunas float viram NULL: o MSSQL FLOAT nao aceita os especiais IEEE.
    for i, campo in enumerate(tab.schema):
        if pa.types.is_floating(campo.type):
            col = tab.column(i)
            tab = tab.set_column(i, campo.name, pc.if_else(pc.is_finite(col), col, pa.scalar(None, campo.type)))
    return tab


def converter(mdb_path: str, dest: dict, mdb_user: str | None = None, mdb_senha: str | None = None, limit: int | None = None):
    nome = os.path.splitext(os.path.basename(mdb_path))[0].lower()
    src = sql_database(
        credentials=engine_access(mdb_path, mdb_user, mdb_senha),
        reflection_level="full_with_precision",
        backend="pyarrow",
    )
    if limit:
        src.add_limit(limit)
    for tab, res in src.resources.items():  # prefixa o destino: <mdb>_<tabela>
        res.apply_hints(table_name=f"{nome}_{tab}")
        res.add_map(sanitizar_floats)
    pipe = dlt.pipeline(
        pipeline_name=f"conv_{nome}",
        destination=dlt.destinations.mssql(credentials=dest),
        dataset_name="dbo",
        pipelines_dir=os.path.join(_BASE, "_dlt_state"),  # cache efemero (a pasta de trabalho e recriada a cada execucao); evita reusar schema antigo
    )
    return pipe.run(src)


def abrir_log(base: str):
    # redireciona stdout/stderr (nivel Python: prints, tracebacks e logging do dlt) para
    # conversor.log; devolve o console original para as mensagens de progresso. NAO usa
    # os.dup2 de proposito: redirecionar os file descriptors do SO conflita com o driver
    # ODBC do Access (nativo) e derruba o processo (OSError 9 'bad fd' / lost sys.stderr).
    log_path = os.path.join(base, "conversor.log")
    console = sys.stdout
    log_file = open(log_path, "w", encoding="utf-8", errors="replace", buffering=1)
    sys.stdout = log_file
    sys.stderr = log_file
    logging.basicConfig(level=logging.INFO, stream=log_file, force=True,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    return console, log_path


def testar_conexao_mdb(mdb_path: str, senha: str | None) -> str | None:
    # Conexao leve para validar acesso antes de converter; devolve None se OK
    # ou uma descricao curta da falha. SQLSTATE 42000 do driver Access = senha
    # incorreta (a mensagem do driver e localizada, entao classificamos pelo
    # SQLSTATE, nao pelo texto).
    try:
        pyodbc.connect(odbc_access(mdb_path, senha), timeout=5).close()
        return None
    except pyodbc.Error as e:
        if e.args and e.args[0] == "42000":
            return "senha de origem incorreta"
        return (e.args[1] if len(e.args) > 1 else str(e))[:80]


def main():
    ap = argparse.ArgumentParser(description="Converte .mdb (Access) -> SQL Server")
    ap.add_argument("--mdb", required=True, help="arquivo .mdb ou pasta com .mdb")
    ap.add_argument("--server", required=True, help="host ou host,porta do SQL Server")
    ap.add_argument("--user", required=True)
    ap.add_argument("--senha", required=True)
    ap.add_argument("--db", required=True, help="banco de destino (deve existir)")
    ap.add_argument("--mdb-user", default=None, help="usuário dos .mdb protegidos (Access: admin)")
    ap.add_argument("--mdb-senha", default=None, help="senha dos .mdb protegidos")
    ap.add_argument("--limit", type=int, default=None, help="limite de linhas por tabela (smoke)")
    args = ap.parse_args()

    console, log_path = abrir_log(os.path.dirname(os.path.abspath(__file__)))

    def progresso(msg: str):
        console.write(msg + "\n")
        console.flush()
        print(msg, flush=True)  # tambem no log, para dar contexto aos tracebacks

    dest = creds_mssql(args.server, args.user, args.senha, args.db)
    alvos = (
        [args.mdb]
        if args.mdb.lower().endswith(".mdb")
        else sorted(glob.glob(os.path.join(args.mdb, "**", "*.mdb"), recursive=True))
    )
    if not alvos:
        progresso(f"Nenhum arquivo .mdb encontrado em: {args.mdb}")
        sys.exit(1)

    progresso("Conversao Access -> SQL Server")
    progresso(f"Destino: banco '{args.db}' em {args.server}")
    progresso(f"Log detalhado: {log_path}")

    # Preflight: testa a conexao com cada .mdb antes de converter. Os que falham
    # (senha de origem incorreta etc.) sao listados e pulados; converte so os
    # acessiveis.
    progresso(f"Verificando conexao com {len(alvos)} banco(s) de origem...")
    conectados = []
    for m in alvos:
        nome = os.path.basename(m)
        erro = testar_conexao_mdb(m, args.mdb_senha)
        if erro is None:
            conectados.append(m)
            progresso(f"  OK     {nome}")
        else:
            progresso(f"  FALHA  {nome} - {erro}")

    progresso(f"Convertendo {len(conectados)} de {len(alvos)} banco(s).")
    if not conectados:
        progresso("Nenhum banco de origem acessivel. Verifique usuario/senha de origem.")
        return

    ok = 0
    for i, m in enumerate(conectados, 1):
        nome = os.path.basename(m)
        progresso(f"[{i}/{len(conectados)}] {nome}: convertendo...")
        try:
            info = converter(m, dest, mdb_user=args.mdb_user, mdb_senha=args.mdb_senha, limit=args.limit)
            print(info, flush=True)  # detalhe da carga -> log
            progresso(f"[{i}/{len(conectados)}] {nome}: concluido")
            ok += 1
        except Exception as e:
            traceback.print_exc()  # traceback completo -> stderr -> log
            progresso(f"[{i}/{len(conectados)}] {nome}: FALHOU ({type(e).__name__}) - veja o log")

    pulados = len(alvos) - len(conectados)
    final = f"Finalizado: {ok}/{len(conectados)} convertido(s)"
    progresso(final + (f", {pulados} pulado(s) por falha de conexao." if pulados else "."))
    if ok < len(conectados):
        progresso(f"Houve falhas na conversao. Detalhes em: {log_path}")


if __name__ == "__main__":
    main()
