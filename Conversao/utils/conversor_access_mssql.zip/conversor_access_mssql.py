# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "dlt[sql-database]>=1.19",
#     "pyarrow",
#     "pandas",
#     "pyodbc",
#     "sqlalchemy-access",
#     "adbc-driver-manager",
#     "pyyaml",
# ]
# ///
"""Conversor Oxente autocontido — MDB (Access) -> SQL Server (sem parquet intermediário materializado).

Roda via `uv run conversor_access_mssql.py ...` (uv provisiona Python + deps na 1a execucao).
Cada tabela de cada .mdb vira <mdb>_<tabela> (translit + lowercase) no schema dbo
do banco de destino. Disparado pela tab "Configuracao Access" do conversor Sol.NET.

  uv run conversor_access_mssql.py --mdb <arquivo.mdb|pasta> --server <host[,porta]> \
      --user <u> --senha <p> --db <banco> [--mdb-senha <p>] [--limit N]

Diagnostico: escreve um unico conversor_<ts>.log direto em disco -- frontmatter YAML no topo
(telemetria de ambiente/destino, pronta no inicio) seguido do corpo cronologico, cada linha
prefixada pela fonte (prog | dlt | erro | meta). Ver abrir_log.

Ao fim, roda uma verificacao de integridade (origem x destino) no MESMO log: por tabela compara
COUNT(*), nº de colunas e SUM por coluna numerica. Ver verificar_integridade.
"""
import argparse
import collections
import decimal
import glob
from datetime import datetime
import importlib.metadata
import locale
import logging
import math
import os
import platform
import subprocess
import sys
import traceback
import unicodedata

import dlt
import pyarrow as pa
import pyarrow.compute as pc
import pyodbc
import sqlalchemy as sa
import yaml
from dlt.common.normalizers.naming.sql_ci_v1 import NamingConvention as _NamingBase
from dlt.sources.sql_database import sql_database
from sqlalchemy_access.base import AccessDialect

# sqlalchemy-access 2.0.3 abre uma conexao DAO COM (DAO.DBEngine.OpenDatabase) por tabela
# para refletir PK/FK e nao libera o handle -> "Too many client tasks" acumulando entre os
# .mdb (todos rodam no mesmo processo). Colunas/tipos vem via ODBC (sem COM); PK/FK sao
# dispensaveis aqui (carga e write_disposition=replace, sem merge). Neutralizar elimina o DAO.
AccessDialect.get_pk_constraint = lambda self, conn, table_name, schema=None, **kw: {"constrained_columns": [], "name": None}
AccessDialect.get_foreign_keys = lambda self, conn, table_name, schema=None, **kw: []

# a pasta do script no PYTHONPATH (herdado pelos subprocessos de normalizacao do dlt,
# que rodam via spawn no Windows) para que o dlt reimporte este modulo pelo nome
# (SCHEMA__NAMING) e carregue a NamingConvention. sys.path cobre o processo atual.
_BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _BASE)
os.environ["PYTHONPATH"] = _BASE + os.pathsep + os.environ.get("PYTHONPATH", "")
os.environ["SCHEMA__NAMING"] = "conversor_access_mssql"
# WARNING+ no dlt: o nivel INFO e ~99% maquinario por tabela (normalizer/parquet/jobs criados,
# "seen data for the first time"); sem valor diagnostico quando nao ha erro. Retry/falha saem em
# WARNING+ e sobrevivem. Corta a secao EVENTOS DLT de ~2400 linhas para um punhado.
os.environ.setdefault("RUNTIME__LOG_LEVEL", "WARNING")
# buffer in-memory: deixar o default do dlt (buffer_max_items=5000). Medido no mvddados: o antigo
# override "4" custava ~41% (extract+load); o default vence. Rotacao de arquivo (file_max_items)
# nao compensa aqui -- pyarrow pula o normalizer e o extract do Access e serial (so adiciona overhead).
# apaga o load package apos cada carga -> nao duplica o dado em disco (parquet intermediario).
os.environ["LOAD__DELETE_COMPLETED_JOBS"] = "true"

ACCESS_DRIVER = "Microsoft Access Driver (*.mdb, *.accdb)"


class NamingConvention(_NamingBase):
    # sql_ci (lowercase, case-insensitive, SQL-safe) + transliteracao de acentos via
    # NFKD (ç->c, ó->o): nomes previsiveis e ASCII no destino. Selecionada pelo env acima.
    def normalize_identifier(self, identifier: str) -> str:
        ascii_id = "".join(
            c for c in unicodedata.normalize("NFKD", identifier) if not unicodedata.combining(c)
        )
        return super().normalize_identifier(ascii_id)


def odbc_access(mdb_path: str, senha: str | None) -> str:
    s = "DRIVER={" + ACCESS_DRIVER + "};DBQ=" + mdb_path + ";"
    return s + ("PWD=" + senha + ";" if senha else "")


def engine_access(mdb_path: str, user: str | None, senha: str | None):
    # senha em dois lugares: odbc_connect (pyodbc nas queries) e url.password
    # (sqlalchemy-access reflete PK/FK via DAO/COM, que le url.password).
    url = sa.engine.URL.create(
        "access+pyodbc",
        username=user or ("admin" if senha else None),
        password=senha or None,
        query={"odbc_connect": odbc_access(mdb_path, senha)},
    )
    return sa.create_engine(url, poolclass=sa.pool.NullPool)


def creds_mssql(server: str, user: str, senha: str, db: str) -> dict:
    host, _, porta = server.partition(",")
    return {
        "drivername": "mssql",
        "host": host,
        "port": int(porta) if porta else 1433,
        "database": db,
        "username": user,
        "password": senha,
        "query": {"driver": "ODBC Driver 17 for SQL Server", "TrustServerCertificate": "yes"},
    }


# TEMP: handle do log p/ instrumentar sanitizar_floats. Setado em main apos abrir_log.
# Remover junto com o bloco "TEMP" dentro de sanitizar_floats quando nao for mais preciso.
_LOG_FLT = None


def sanitizar_floats(tab: pa.Table) -> pa.Table:
    # NaN/Inf em colunas float viram NULL: o MSSQL FLOAT nao aceita os especiais IEEE.
    for i, campo in enumerate(tab.schema):
        if pa.types.is_floating(campo.type):
            col = tab.column(i)
            limpo = pc.if_else(pc.is_finite(col), col, pa.scalar(None, campo.type))
            # TEMP: loga os nao-finitos trocados (original -> NULL). So emite quando ha troca,
            # entao tabelas limpas ficam silenciosas. is_valid exclui os NULL ja existentes.
            if _LOG_FLT is not None:
                ruins = pc.and_kleene(pc.is_valid(col), pc.invert(pc.is_finite(col)))
                n = pc.sum(pc.cast(ruins, pa.int64())).as_py() or 0
                if n:
                    distintos = pc.unique(col.filter(ruins)).to_pylist()
                    print(f"{_ts()} flt  | {campo.name}: {n} nao-finito(s) -> NULL; "
                          f"originais distintos={distintos}", file=_LOG_FLT, flush=True)
            tab = tab.set_column(i, campo.name, limpo)
    return tab


# ----------------------------------------------------------------------------- telemetria (A)
def _ver(dist: str) -> str | None:
    try:
        return importlib.metadata.version(dist)
    except Exception:
        return None


def _uv_version() -> str | None:
    try:
        import subprocess

        r = subprocess.run(["uv", "--version"], capture_output=True, text=True, timeout=5)
        return r.stdout.strip() or None
    except Exception:
        return None


def _ram_mb() -> int | None:
    # RAM fisica total via Win32 GlobalMemoryStatusEx; best-effort (None fora do Windows).
    try:
        import ctypes

        class _MS(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        m = _MS()
        m.dwLength = ctypes.sizeof(_MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return m.ullTotalPhys // (1024 * 1024)
    except Exception:
        return None


def coletar_drivers() -> dict:
    # so o que discrimina uma falha de conexao: os drivers ODBC que o pyodbc enxerga no bitness
    # do Python (Access ausente -> nao le origem; ODBC SQL Server ausente -> nao conecta destino).
    # ponytail: cortada a varredura de registro nos 2 bitness + ADBC -- era andaime do bug de
    # bitness, ja resolvido. O bitness do Python sai em ambiente.python_bits; o caminho de carga
    # (ADBC parquet x insert_values) sai no log do dlt. Reexpandir so se o bitness voltar a morder.
    # adbc_manager: versao do adbc-driver-manager (None = ausente -> carga cai em insert_values).
    # Nao detecta o driver mssql em si (sai no log do dlt: parquet x insert_values); so o manager.
    odbc = []
    try:
        odbc = sorted(pyodbc.drivers())
    except Exception:
        pass
    return {"odbc_runtime": odbc, "adbc_manager": _ver("adbc-driver-manager")}


def coletar_ambiente(args) -> dict:
    return {
        "python": sys.version.split()[0],
        "python_bits": platform.architecture()[0],
        "python_exe": sys.executable,
        "plataforma": platform.platform(),
        "cpus": os.cpu_count(),
        "ram_mb": _ram_mb(),
        "encoding": locale.getpreferredencoding(False),
        "uv": _uv_version(),
        "venv": sys.prefix,
        "deps": {d: _ver(d) for d in (
            "dlt", "pyarrow", "pyodbc", "sqlalchemy", "sqlalchemy-access", "adbc-driver-manager")},
        "drivers": coletar_drivers(),
        "envs": {k: os.environ.get(k) for k in ("SCHEMA__NAMING", "RUNTIME__LOG_LEVEL")},
        "args": {"server": args.server, "db": args.db, "mdb": args.mdb, "limit": args.limit},
    }


def _odbc_mssql(dest: dict) -> str:
    return (
        f"DRIVER={{{dest['query']['driver']}}};SERVER={dest['host']},{dest['port']};"
        f"DATABASE={dest['database']};UID={dest['username']};PWD={dest['password']};"
        "TrustServerCertificate=yes;"
    )


def coletar_destino_sql(dest: dict) -> dict:
    # versao/edicao/bitness e collation do destino: o que discrimina uma instancia da outra
    # (o erro 8631 passa numa e estoura noutra). CAST AS NVARCHAR porque SERVERPROPERTY
    # devolve sql_variant, que o pyodbc nao decodifica ("ODBC SQL type -16 is not supported").
    dados: dict = {}
    try:
        cn = pyodbc.connect(_odbc_mssql(dest), timeout=10)
        cur = cn.cursor()
        cur.execute("SELECT @@VERSION")
        dados["version"] = cur.fetchone()[0]
        cur.execute(
            "SELECT CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('ProductLevel') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('EngineEdition') AS NVARCHAR(128)),"
            " CAST(SERVERPROPERTY('Collation') AS NVARCHAR(128))"
        )
        pv, pl, ed, ee, col = cur.fetchone()
        dados.update(product_version=pv, product_level=pl, edition=ed,
                     engine_edition=ee, server_collation=col)
        cur.execute(
            "SELECT CAST(collation_name AS NVARCHAR(128)), compatibility_level"
            " FROM sys.databases WHERE name = ?", dest["database"])
        r = cur.fetchone()
        if r:
            dados["db_collation"], dados["db_compatibility_level"] = r[0], r[1]
        dados["odbc_driver"] = cn.getinfo(pyodbc.SQL_DRIVER_NAME)
        dados["odbc_driver_version"] = cn.getinfo(pyodbc.SQL_DRIVER_VER)
        cn.close()
    except Exception as e:
        dados["erro"] = str(e)[:200]
    return dados


# drivers necessarios. Access e ODBC 17 via winget (machine-scope); ADBC mssql via dbc (evita o
# caminho insert_values, ~10-70x mais lento). Script roda SEMPRE elevado (janela do Sol.NET);
# winget sempre nao-interativo. Instala so o que falta. (uv ja vem garantido pelo bootstrap.ps1.)
WINGET_ACCESS = "Microsoft.AccessDatabaseEngine.2016"
WINGET_ODBC17 = "Microsoft.msodbcsql.17"
_NAO_INTERATIVO = ["--silent", "--disable-interactivity",
                   "--accept-package-agreements", "--accept-source-agreements"]


def _winget_tem(wid: str) -> bool:
    # winget list -e --id <id>: sai 0 e ecoa o id quando instalado.
    r = subprocess.run(["winget", "list", "-e", "--id", wid,
                        "--accept-source-agreements", "--disable-interactivity"],
                       capture_output=True, text=True)
    return r.returncode == 0 and wid.lower() in (r.stdout or "").lower()


def _dbc_tem_mssql() -> bool:
    # dbc list ecoa os drivers ADBC instalados; "mssql" presente = nao reinstala.
    r = subprocess.run(["uv", "tool", "run", "dbc", "list"], capture_output=True, text=True)
    return r.returncode == 0 and "mssql" in (r.stdout or "").lower()


def garantir_drivers() -> None:
    # 1) ADBC mssql via dbc; 2) Access e ODBC 17 via winget. O uv ja vem garantido pelo bootstrap.ps1
    # (que roda este script via `uv run`), entao nao se instala uv aqui -- seria circular.
    if not _dbc_tem_mssql():
        subprocess.run(["uv", "tool", "run", "dbc", "install", "mssql"])
    for wid in (WINGET_ACCESS, WINGET_ODBC17):
        if not _winget_tem(wid):
            subprocess.run(["winget", "install", "-e", "--id", wid, *_NAO_INTERATIVO])


def metricas_carga(pipe) -> dict:
    # tempos por etapa do trace do dlt; best-effort (isolado para nao derrubar o
    # resultado se a API do trace variar).
    out: dict = {}
    try:
        out["tempos_s"] = {
            s.step: round((s.finished_at - s.started_at).total_seconds(), 2)
            for s in pipe.last_trace.steps if s.started_at and s.finished_at
        }
    except Exception:
        pass
    return out


def carregar(engine, nome: str, dest: dict, limit: int | None, log) -> object:
    # chunk_size grande: o gargalo e o extract (leitura do Access). Default do dlt e 1000
    # linhas/batch -> muitos round-trips pyodbc/Jet; 50k corta a maioria das tabelas em 1-2 batches.
    reflexao = os.environ.get("CONV_REFLECTION", "full_with_precision")
    src = sql_database(credentials=engine, reflection_level=reflexao, backend="pyarrow")
    if limit:
        src.add_limit(limit)
    for tab, res in src.resources.items():  # prefixa o destino: <mdb>_<tabela>
        # replace: cada run substitui a tabela no destino -> conversao idempotente. O default
        # do dlt e append, que DUPLICARIA os dados a cada reexecucao no mesmo banco de destino.
        res.apply_hints(table_name=f"{nome}_{tab}", write_disposition="replace")
        res.add_map(sanitizar_floats)
    pipe = dlt.pipeline(
        pipeline_name=f"conv_{nome}",
        destination=dlt.destinations.mssql(credentials=dest),
        dataset_name="dbo",
        pipelines_dir=os.path.join(_BASE, "_dlt_state"),  # cache efemero; evita reusar schema antigo
    )
    info = pipe.run(src)
    print(f"{_ts()} dlt  | resumo conv_{nome}:\n{info}", file=log, flush=True)  # resumo tecnico da carga
    return pipe


# ----------------------------------------------------------------------------- logging / merge
def _ts() -> str:
    # hora da linha (HH:MM:SS); a data ja esta no nome do arquivo conversor_<AAAAMMDD>_*.
    return datetime.now().strftime("%H:%M:%S")


def abrir_log(base: str, frontmatter: dict):
    # 1 arquivo cronologico: frontmatter YAML (telemetria, pronta no inicio) + corpo prefixado
    # por timestamp e fonte (prog|dlt|erro|meta). Escreve direto -> resiliente a crash (parciais ficam).
    # NAO usa os.dup2: redirecionar o fd do SO conflita com o driver ODBC do Access (OSError 9).
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    f = open(os.path.join(base, f"conversor_{ts}.log"), "w", encoding="utf-8",
             errors="replace", buffering=1)
    f.write("---\n" + yaml.safe_dump(frontmatter, default_flow_style=False,
                                     allow_unicode=True, sort_keys=False) + "---\n\n")
    orig = sys.stderr
    sys.stderr = f  # o StreamHandler do dlt captura sys.stderr na 1a carga; o format da o prefixo
    logging.basicConfig(level=logging.WARNING, stream=f, force=True, datefmt="%H:%M:%S",
                        format="%(asctime)s dlt  | %(levelname)s %(name)s %(message)s")
    return orig, f


def testar_conexao_mdb(mdb_path: str, senha: str | None) -> str | None:
    # Conexao leve para validar acesso antes de converter; devolve None se OK
    # ou uma descricao curta da falha. SQLSTATE 42000 do driver Access = senha
    # incorreta (a mensagem do driver e localizada, entao classificamos pelo
    # SQLSTATE, nao pelo texto).
    try:
        pyodbc.connect(odbc_access(mdb_path, senha), timeout=5).close()
        return None
    except pyodbc.Error as e:
        if e.args and e.args[0] == "42000":
            return "senha de origem incorreta"
        return (e.args[1] if len(e.args) > 1 else str(e))[:80]


# ============================================================= verificacao de integridade (pos-run)
# Transposto do antigo checar_conversao.py. Por tabela, compara origem (.mdb) x destino (SQL Server):
# COUNT(*), nº de colunas e SUM por coluna numerica (degrau de conteudo barato). Roda no MESMO
# conversor_<ts>.log, sobre os .mdb que converteram -- reusa NamingConvention/odbc/dest/nomes daqui.
_naming = NamingConvention()
_LARG = 70
_STATUS_LEGENDA = [
    ("OK",    "linhas, colunas e somas conferem entre origem e destino."),
    ("VAZIA", "a tabela não tem linhas na origem e, por isso, não é criada no destino."),
    ("FALTA", "a tabela existe na origem, mas não chegou ao destino."),
    ("DIFF",  "a contagem de linhas ou de colunas diverge entre origem e destino."),
    ("SOMA",  "a soma de alguma coluna numérica não confere entre origem e destino."),
]
_COLS = [
    ("STATUS", "status"), ("TABELA ORIGEM", "tab"), ("TABELA DESTINO", "destino"),
    ("LINHAS ORIGEM", "lo"), ("LINHAS DESTINO", "ld"),
    ("COLUNAS ORIGEM", "co"), ("COLUNAS DESTINO", "cd"),
]
_NS = object()  # sentinela: coluna nao-somavel (o proprio motor estoura ao agregar)


def _tabelas_origem(conn) -> list[str]:
    # tabelas de usuario do .mdb (exclui as de sistema MSys*).
    return [r.table_name for r in conn.cursor().tables(tableType="TABLE")
            if not r.table_name.startswith("MSys")]


def _n_linhas(conn, ident: str) -> int | None:
    # COUNT(*) da tabela; None se nao existe no destino.
    try:
        return conn.cursor().execute(f"SELECT COUNT(*) FROM {ident}").fetchone()[0]
    except pyodbc.Error:
        return None


def _n_colunas_origem(conn, tab: str) -> int | None:
    # via cursor.description; .columns() do driver Access as vezes estoura UTF-16 invalido em REMARKS.
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM [{tab}] WHERE 1=0")
        n = len(cur.description)
        cur.close()
        return n
    except Exception:
        return None


def _n_colunas_destino(conn, tabela: str) -> int | None:
    # exclui as colunas tecnicas do dlt (_dlt_id, _dlt_load_id).
    try:
        return conn.cursor().execute(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo'"
            " AND TABLE_NAME=? AND COLUMN_NAME NOT LIKE '\\_dlt%' ESCAPE '\\'", tabela).fetchone()[0]
    except pyodbc.Error:
        return None


def _cols_num_origem(conn, tab: str) -> list[str]:
    # nomes das colunas numericas (exclui bool/Yes-No e nao-numericos), via cursor.description.
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM [{tab}] WHERE 1=0")
    nums = [d[0] for d in cur.description
            if d[1] in (int, float, decimal.Decimal) and d[1] is not bool]
    cur.close()
    return nums


def _colunas_destino_set(conn, tabela: str) -> set[str]:
    return {r[0] for r in conn.cursor().execute(
        "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME=?",
        tabela).fetchall()}


def _somar(conn, tabela_ident: str, colunas: list[str], cast: str) -> list:
    # uma query: SUM de cada coluna (cast p/ nao estourar o tipo nativo). Se a multi-coluna estoura,
    # isola coluna-a-coluna REUSANDO um cursor (recriado so apos erro) -- abrir um por coluna pressiona
    # o teto de ~32 client tasks do ACE numa conexao carregada -> _NS espurio. _NS = nao-somavel.
    if not colunas:
        return []
    exprs = ", ".join(cast.format(c=c) for c in colunas)
    try:
        return list(conn.cursor().execute(f"SELECT {exprs} FROM {tabela_ident}").fetchone())
    except pyodbc.Error:
        out, cur = [], conn.cursor()
        for c in colunas:
            try:
                out.append(cur.execute(f"SELECT {cast.format(c=c)} FROM {tabela_ident}").fetchone()[0])
            except pyodbc.Error:
                out.append(_NS)
                cur = conn.cursor()  # o handle pode ficar sujo apos o erro
        cur.close()
        return out


def _aprox(a, b) -> bool:
    # somas vem como float dos dois lados (*1.0 / CAST FLOAT) -> tolerancia 1e-6 absorve
    # arredondamento Access x MSSQL e o NaN/Inf->NULL do sanitizar_floats. None so casa com None.
    if a is None or b is None:
        return a is None and b is None
    return math.isclose(float(a), float(b), rel_tol=1e-6, abs_tol=1e-6)


def _checar_somas(cn_src, tab: str, cn_dest, destino: str) -> tuple[list, list]:
    # SUM por coluna numerica nos dois lados (uma query agregada cada), em float p/ nao estourar.
    # devolve (difs, naoverif): difs = divergencias (valor ou coluna ausente); naoverif = colunas
    # que o motor nao agrega (overflow no proprio Access -- lixo nao-finito ja zerado no destino).
    # ponytail: float perde exatidao em somas de IDs gigantes -- pega divergencia grosseira, nao
    # bit-a-bit. Se precisar exato, CDec/DECIMAL(38) nos dois lados.
    cols = _cols_num_origem(cn_src, tab)
    if not cols:
        return [], []
    dest_cols = _colunas_destino_set(cn_dest, destino)
    # [col]*1.0 promove a double no Jet (mata o overflow do SUM de Long) e propaga NULL sem erro.
    somas_o = _somar(cn_src, f"[{tab}]", cols, "SUM([{c}]*1.0)")
    mapeadas = [(c, _naming.normalize_identifier(c), so) for c, so in zip(cols, somas_o)]
    presentes = [m for m in mapeadas if m[1] in dest_cols]
    difs = [(c, "?", "coluna ausente no destino") for (c, cd, _) in mapeadas if cd not in dest_cols]
    naoverif = []
    if presentes:
        somas_d = _somar(cn_dest, f"dbo.[{destino}]", [cd for _, cd, _ in presentes], "SUM(CAST([{c}] AS FLOAT))")
        for (c, _, so), sd in zip(presentes, somas_d):
            if so is _NS or sd is _NS:
                naoverif.append(c)
            elif not _aprox(so, sd):
                difs.append((c, so, sd))
    return difs, naoverif


def _mil(n) -> str:
    # separador de milhar pt-br: int 398561 -> "398.561"; float -> "1.234.567,89"; None -> "—".
    if n is None:
        return "—"
    if isinstance(n, float):
        return f"{n:,.2f}".translate(str.maketrans(",.", ".,"))
    return f"{n:,}".replace(",", ".")


def _largura(rotulo: str, valores) -> int:
    # largura da coluna = o maior entre o rotulo e o conteudo deste grupo (nunca corta o rotulo).
    return max(len(rotulo), max((len(v) for v in valores), default=0))


def _observacao(x: dict) -> str:
    # consolida soma divergente / coluna ausente / nao-verificavel numa celula so.
    partes = [f"coluna ausente: {col}" if vo == "?" else f"soma {col}: {_mil(vo)} ≠ {_mil(vd)}"
              for col, vo, vd in x["difs"]]
    if x["naoverif"]:
        partes.append(f"não verif.: {', '.join(x['naoverif'])} (estouro no Access)")
    return "; ".join(partes)


def _imprimir_grupo(linhas: list[dict]) -> None:
    # alinhamento LOCAL (larguras do proprio .mdb) + separadores "│" e regua. OBSERVAÇÃO e a ultima
    # coluna, sem borda a direita -> absorve as anotacoes e pode vazar livre.
    if not linhas:
        print("  (sem tabelas de usuário)")
        return
    for x in linhas:
        x["obs"] = _observacao(x)
    larg = {ch: _largura(rot, [x[ch] for x in linhas]) for rot, ch in _COLS}

    def montar(vals: dict) -> str:
        fixas = " │ ".join(f"{vals[ch]:{larg[ch]}}" for _, ch in _COLS)
        return f"  {fixas} │ {vals['obs']}"

    cabec = {ch: rot for rot, ch in _COLS} | {"obs": "OBSERVAÇÃO"}
    linha_cabec = montar(cabec)
    print(linha_cabec)
    print("".join("┼" if c == "│" else "─" for c in linha_cabec))  # regua alinhada ao cabecalho
    for x in linhas:
        print(montar(x))


def _imprimir_legenda() -> None:
    # origem/destino/inicio ja estao no frontmatter YAML do log -> aqui so o titulo + a legenda.
    print("═" * _LARG)
    print(" VERIFICAÇÃO DE INTEGRIDADE — origem (.mdb) × destino (SQL Server)")
    print("─" * _LARG)
    for i, (rotulo, expl) in enumerate(_STATUS_LEGENDA):
        if i:
            print()  # quebra de linha entre cada item da legenda
        print(f" {rotulo:6} -> {expl}")
    print("═" * _LARG)


def _imprimir_resumo(c, divergentes: list, naoverificaveis: list) -> None:
    ndiv = c["FALTA"] + c["DIFF"] + c["SOMA"]
    print("─" * _LARG)
    print(" Resumo")
    print(f"   {c['OK']} OK   ·   {c['VAZIA']} vazias   ·   {ndiv} divergências")
    print(f"   Divergências (linhas/colunas/soma): {', '.join(divergentes) if divergentes else 'nenhuma'}")
    if naoverificaveis:
        print(f"   Somas não verificáveis: {'; '.join(naoverificaveis)}")
    print("═" * _LARG)


def _status_tabela(ls, ld, cs, cd, difs_soma) -> str:
    if ld is None:
        return "VAZIA" if ls == 0 else "FALTA"  # vazia na origem nao e materializada pelo dlt
    if ls != ld or cs != cd:
        return "DIFF"
    return "SOMA" if difs_soma else "OK"


def verificar_integridade(conectados: list, nomes: dict, dest: dict, mdb_senha, log):
    # roda pos-conversao, no MESMO log. Redireciona stdout p/ o log (as funcoes _imprimir_* usam
    # print); o console recebe so um resumo curto (no main). Devolve (contagem, divergentes, naoverif).
    cn_dest = pyodbc.connect(_odbc_mssql(dest))
    contagem = collections.Counter()
    divergentes, naoverificaveis = [], []
    salvo = sys.stdout
    sys.stdout = log
    try:
        print("\n")
        _imprimir_legenda()
        for m in conectados:
            nome = nomes[m]
            print(f"\n▼ {os.path.basename(m)}")
            print(f"  {os.path.abspath(m)}")
            try:
                cn_src = pyodbc.connect(odbc_access(m, mdb_senha), timeout=5)
            except pyodbc.Error as e:
                print(f"  (origem inacessível na verificação: {str(e)[:60]})")
                continue
            linhas = []
            for tab in _tabelas_origem(cn_src):
                destino = _naming.normalize_path(f"{nome}_{tab}")
                ls, ld = _n_linhas(cn_src, f"[{tab}]"), _n_linhas(cn_dest, f"dbo.[{destino}]")
                cs, cd = _n_colunas_origem(cn_src, tab), _n_colunas_destino(cn_dest, destino)
                difs_soma, naoverif = _checar_somas(cn_src, tab, cn_dest, destino) if ld is not None else ([], [])
                status = _status_tabela(ls, ld, cs, cd, difs_soma)
                contagem[status] += 1
                if status in ("FALTA", "DIFF", "SOMA"):
                    divergentes.append(f"{nome}.{tab}")
                if naoverif:
                    naoverificaveis.append(f"{nome}.{tab} ({', '.join(naoverif)})")
                cd_disp = cd if ld is not None else None  # destino ausente -> "—"
                linhas.append({"status": status, "tab": tab, "destino": destino,
                               "lo": _mil(ls), "ld": _mil(ld), "co": _mil(cs), "cd": _mil(cd_disp),
                               "difs": difs_soma, "naoverif": naoverif})
            _imprimir_grupo(linhas)
            cn_src.close()
        cn_dest.close()
        _imprimir_resumo(contagem, divergentes, naoverificaveis)
    finally:
        sys.stdout = salvo
    return contagem, divergentes, naoverificaveis


def main():
    ap = argparse.ArgumentParser(description="Converte .mdb (Access) -> SQL Server")
    ap.add_argument("--mdb", required=True, help="arquivo .mdb ou pasta com .mdb")
    ap.add_argument("--server", required=True, help="host ou host,porta do SQL Server")
    ap.add_argument("--user", required=True)
    ap.add_argument("--senha", required=True)
    ap.add_argument("--db", required=True, help="banco de destino (deve existir)")
    ap.add_argument("--mdb-user", default=None, help="usuário dos .mdb protegidos (Access: admin)")
    ap.add_argument("--mdb-senha", default=None, help="senha dos .mdb protegidos")
    ap.add_argument("--limit", type=int, default=None, help="limite de linhas por tabela (smoke)")
    args = ap.parse_args()

    console = sys.stdout
    dest = creds_mssql(args.server, args.user, args.senha, args.db)
    # frontmatter = telemetria pronta no inicio (ambiente inclui drivers; destino_sql sonda o SQL).
    frontmatter = {"ambiente": coletar_ambiente(args), "destino_sql": coletar_destino_sql(dest)}
    orig_err, log = abrir_log(_BASE, frontmatter)
    global _LOG_FLT  # TEMP: liga a instrumentacao de sanitizar_floats
    _LOG_FLT = log

    def progresso(msg: str):
        console.write(msg + "\n")
        console.flush()
        log.write(f"{_ts()} prog | {msg}\n")

    try:
        garantir_drivers()  # uv + ADBC mssql + Access + ODBC 17; elevado e nao-interativo
        alvos = (
            [args.mdb]
            if args.mdb.lower().endswith(".mdb")
            else sorted(glob.glob(os.path.join(args.mdb, "**", "*.mdb"), recursive=True))
        )
        if not alvos:
            progresso(f"Nenhum arquivo .mdb encontrado em: {args.mdb}")
            return

        # o mesmo basename em subpastas distintas colidiria no destino e, com replace, um mdb
        # sobrescreveria o outro (homonimo vazio zerando o cheio). Na duvida, converter TODOS:
        # pre-calcula um nome unico por mdb antes da run -- a 1a ocorrencia (ordem do sorted)
        # mantem o nome limpo, as seguintes recebem sufixo _2, _3... (curto, cabe nos 128 do mssql).
        base_dir = os.path.dirname(args.mdb) if args.mdb.lower().endswith(".mdb") else args.mdb
        seq: dict = collections.Counter()
        nomes: dict = {}
        for a in alvos:
            base = os.path.splitext(os.path.basename(a))[0].lower()
            seq[base] += 1
            nomes[a] = base if seq[base] == 1 else f"{base}_{seq[base]}"
        renomeados = {a: n for a, n in nomes.items()
                      if n != os.path.splitext(os.path.basename(a))[0].lower()}
        if renomeados:
            progresso(f"{len(renomeados)} .mdb de nome duplicado -> sufixo numerico:")
            for a, n in renomeados.items():
                progresso(f"  {os.path.relpath(a, base_dir)} -> {n}")

        progresso("Conversao Access -> SQL Server")
        progresso(f"Destino: banco '{args.db}' em {args.server}")
        progresso(f"Log detalhado: {log.name}")

        # Preflight: testa a conexao com cada .mdb antes de converter. Os que falham
        # (senha de origem incorreta etc.) sao listados e pulados; converte so os acessiveis.
        progresso(f"Verificando conexao com {len(alvos)} banco(s) de origem...")
        conectados = []
        for m in alvos:
            erro = testar_conexao_mdb(m, args.mdb_senha)
            if erro is None:
                conectados.append(m)
                progresso(f"  OK     {os.path.basename(m)}")
            else:
                progresso(f"  FALHA  {os.path.basename(m)} - {erro}")

        progresso(f"Convertendo {len(conectados)} de {len(alvos)} banco(s).")
        if not conectados:
            progresso("Nenhum banco de origem acessivel. Verifique usuario/senha de origem.")
            return

        ok = 0
        for i, m in enumerate(conectados, 1):
            nome = nomes[m]
            nome_mdb = os.path.relpath(m, base_dir) if m in renomeados else os.path.basename(m)
            progresso(f"[{i}/{len(conectados)}] {nome_mdb}: convertendo...")
            engine = engine_access(m, args.mdb_user, args.mdb_senha)
            try:
                pipe = carregar(engine, nome, dest, args.limit, log)
                log.write(f"{_ts()} meta | {nome_mdb} ok {metricas_carga(pipe).get('tempos_s', {})}\n")
                progresso(f"[{i}/{len(conectados)}] {nome_mdb}: concluido")
                ok += 1
            except Exception as e:
                log.write(f"{_ts()} erro | {nome_mdb}: {type(e).__name__}: {e}\n")
                traceback.print_exc(file=log)  # traceback completo como bloco
                progresso(f"[{i}/{len(conectados)}] {nome_mdb}: FALHOU ({type(e).__name__}) - veja o log")

        pulados = len(alvos) - len(conectados)
        final = f"Finalizado: {ok}/{len(conectados)} convertido(s)"
        progresso(final + (f", {pulados} pulado(s) por falha de conexao." if pulados else "."))
        if ok < len(conectados):
            progresso(f"Houve falhas na conversao. Detalhes em: {log.name}")

        # pos-run: verificacao de integridade (origem x destino) no MESMO log
        progresso("Verificando integridade da conversao (origem x destino)...")
        cont, _, nverif = verificar_integridade(conectados, nomes, dest, args.mdb_senha, log)
        ndiv = cont["FALTA"] + cont["DIFF"] + cont["SOMA"]
        progresso(f"Verificacao: {cont['OK']} OK, {cont['VAZIA']} vazias, {ndiv} divergencia(s),"
                  f" {len(nverif)} soma(s) nao verificavel(is). Detalhes no log.")
    finally:
        sys.stderr = orig_err
        log.close()


if __name__ == "__main__":
    main()
