# Bootstrap do conversor Access -> SQL Server.
# Garante o uv (via winget, latest) e roda o conversor_access_mssql.py repassando os argumentos
# recebidos do app (Sol.NET). O Sol.NET abre esta janela elevada e user-facing: o operador
# acompanha o progresso e le o resumo no fim -- por isso o Read-Host segura a janela ate ele fechar.
# O exit code e propagado p/ o Sol.NET ramificar.
#
# Compativel com Windows PowerShell 5.1: sem dependencia de rede/zip; so winget + recarga de PATH
# (Get-Command, winget e [Environment]::GetEnvironmentVariable sao todos 5.1-OK).

$ErrorActionPreference = 'Stop'
$code = 0

try
{
    $PyScript = Join-Path $PSScriptRoot 'conversor_access_mssql.py'
    if (-not (Test-Path $PyScript))
    {
        throw "conversor_access_mssql.py nao encontrado em $PSScriptRoot"
    }

    # uv via winget (sem pin -> latest). Idempotente: instala so se ausente. O winget cria o shim
    # em %LOCALAPPDATA%\Microsoft\WinGet\Links, que so entra no PATH de sessoes novas -> recarrega o
    # PATH (Machine+User) para enxergar o uv recem-instalado ainda nesta sessao.
    if (-not (Get-Command uv -ErrorAction SilentlyContinue))
    {
        Write-Host 'uv nao encontrado. Instalando via winget...'
        winget install -e --id astral-sh.uv --silent --disable-interactivity --accept-package-agreements --accept-source-agreements
        $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                    [Environment]::GetEnvironmentVariable('Path', 'User')
    }

    # @args = argumentos do app (--mdb, --server, --user, --senha, --db, --mdb-user,
    # --mdb-senha, --limit), repassados ao uv via splatting.
    uv run $PyScript @args
    $code = $LASTEXITCODE
}
catch
{
    Write-Host ('ERRO no bootstrap da conversao: ' + $_.Exception.Message)
    $code = 1
}
finally
{
    Write-Host ''
    Read-Host 'Processo finalizado. Pressione Enter para fechar'
}
exit $code
