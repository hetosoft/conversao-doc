# Bootstrap do conversor Access -> SQL Server.
# Garante uma versao FIXA do uv em cache por maquina (baixa de github se faltar)
# e roda o conversor_access_mssql.py repassando os argumentos recebidos do app.
# Mantem a janela aberta ao terminar (sucesso ou erro) para o operador ler o log.
#
# Compativel com Windows PowerShell 5.1 (powershell.exe): TLS 1.2 explicito,
# Invoke-WebRequest -UseBasicParsing, Expand-Archive; sem sintaxe de PS 7+.

$ErrorActionPreference = 'Stop'

# Pin: a mesma versao validada no empacotamento. Nao usar "latest" — mudaria o
# comportamento sem alteracao de codigo. Para atualizar, troque so este numero.
$UvVersion = '0.11.21'
$UvArch = 'x86_64-pc-windows-msvc'

try
{
    $ScriptDir = $PSScriptRoot
    $PyScript = Join-Path $ScriptDir 'conversor_access_mssql.py'
    if (-not (Test-Path $PyScript))
    {
        throw "conversor_access_mssql.py nao encontrado em $ScriptDir"
    }

    # Cache por maquina, versionado pelo numero do uv: troca de versao nao
    # colide com a anterior e o primeiro run de cada versao baixa uma vez.
    $CacheDir = Join-Path $env:LOCALAPPDATA ('hetosoft\uv\' + $UvVersion)
    $UvExe = Join-Path $CacheDir 'uv.exe'

    if (-not (Test-Path $UvExe))
    {
        Write-Host "uv $UvVersion nao esta em cache. Baixando uma unica vez..."
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $Url = "https://github.com/astral-sh/uv/releases/download/$UvVersion/uv-$UvArch.zip"
        $TmpZip = Join-Path $env:TEMP ("uv-$UvVersion-$UvArch.zip")
        Invoke-WebRequest -Uri $Url -OutFile $TmpZip -UseBasicParsing
        if (-not (Test-Path $CacheDir))
        {
            New-Item -ItemType Directory -Path $CacheDir -Force | Out-Null
        }
        Expand-Archive -Path $TmpZip -DestinationPath $CacheDir -Force
        Remove-Item $TmpZip -Force -ErrorAction SilentlyContinue
        if (-not (Test-Path $UvExe))
        {
            throw "uv.exe nao encontrado apos extrair $Url"
        }
        Write-Host "uv instalado em $UvExe"
    }

    # @args = argumentos recebidos do app (--mdb, --server, --user, --senha,
    # --db, --mdb-user, --mdb-senha, --limit), repassados ao uv via splatting.
    & $UvExe run $PyScript @args
}
catch
{
    Write-Host ''
    Write-Host ('ERRO no bootstrap da conversao: ' + $_.Exception.Message)
}
finally
{
    Write-Host ''
    Read-Host 'Processo finalizado. Pressione Enter para fechar'
}
